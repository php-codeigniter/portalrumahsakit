<?php
include 'module/koneksi.php';
		$id_prov = $_POST['id_prov'];
		$query = "SELECT * tbl_master_kab.nama_kab FROM tbl_master_prov LEFT JOIN tbl_master_kab ON tbl_master_prov.id_prov = tbl_master_kab.id_kab ORDER BY tbl_master_prov.id_prov";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		{
	echo '<option value="'.$data['id_prov'].'">'.$data['nama_kab'].'</option>';
}
?>