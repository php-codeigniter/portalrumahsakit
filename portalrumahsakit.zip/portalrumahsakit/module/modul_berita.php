<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		
		$id = $_POST['id'];
		$kategori = $_POST['kategori'];
		$judul = $_POST['judul'];
		$isi_berita = $_POST['isi_berita'];
		$tanggal = date('Y-m-d');
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO berita (id,kategori,judul,isi_berita,tanggal,foto) 
				  VALUES ('$id','$kategori','$judul','$isi_berita','$tanggal','$foto')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Berita Berhasil Ditambahkan');
					window.location.href='../index.php?page=berita';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=berita';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM berita WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Berita berhasil Dihapus');
					window.location.href='../index.php?page=berita';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=berita';
				</script>
			";
		}
	break;
	
	case "update" :
	
		$id = $_POST['id'];
		$kategori = $_POST['kategori'];
		$judul = $_POST['judul'];
		$isi_berita = $_POST['isi_berita'];
		$tanggal = date('Y-m-d');
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";

		move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE berita SET kategori='$kategori',judul='$judul',isi_berita='$isi_berita',tanggal='$tanggal',foto='$foto' WHERE id='$id'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('Berita Berhasil Diperbarui');
					window.location.href='../index.php?page=berita';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=berita';
				</script>
			";
		}
	break;
}
?>