<?php error_reporting(0);
require ("koneksi.php");

$action = $_GET['action'];

switch($action) {
	case "add" :
		$id = $_POST['id'];
		$nama_pel = $_POST['nama_pel'];
	    move_uploaded_file($lokasi_file,$direktori); 
		$query="INSERT INTO tbl_katpel (id,nama_pel) 
				VALUES ('$id','$nama_pel')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Kategori Pelayanan Berhasil Ditambahkan');
					window.location.href='../index.php?page=katpel';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=katpel';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_katpel WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Nama Kategori Pelayanan Berhasil Dihapus');
					window.location.href='../index.php?page=katpel';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=katpel';
				</script>
			";
		}
	break;
	
	case "update" :

		$id = $_POST ['id'];
		$nama_pel = $_POST ['nama_pel'];
	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE tbl_katpel SET nama_pel='$nama_pel' WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Kategori Pelayanan Berhasil Diperbahrui');
					window.location.href='../index.php?page=katpel';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=katpel';
				</script>
			";
		}
	break;
}
?>