<?php error_reporting(0);
include("koneksi.php");
session_start();
if(!isset($_SESSION['user']) || $_SESSION['type'] != "administrator") {
		echo "<script type = 'text/javascript'>
						window.location.href='home.php?menu=home';
			 </script>
			";
}
?>