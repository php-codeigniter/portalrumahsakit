<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		$id = $_POST['id'];
		$status_bekerja = $_POST['status_bekerja'];
		$status_penempatan = $_POST['status_penempatan'];
		$jumlah = $_POST['jumlah'];
		
		$query = "INSERT INTO tbl_statistik (id,status_bekerja,status_penempatan,jumlah) 
				  VALUES ('$id','$status_bekerja','$status_penempatan','$jumlah')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Statistik Berhasil Ditambahkan');
					window.location.href='../index.php?page=statistik';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=statistik';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_statistik WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Nama Statistik Berhasil Dihapus');
					window.location.href='../index.php?page=statistik';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=statistik';
				</script>
			";
		}
	break;
	
	case "update" :
		
		$id = $_POST['id'];
		$status_bekerja = $_POST['status_bekerja'];
		$status_penempatan = $_POST['status_penempatan'];
		$jumlah = $_POST['jumlah'];
		
		$query = "UPDATE tbl_statistik SET status_bekerja='$status_bekerja',status_penempatan='$status_penempatan',jumlah='$jumlah' WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Statistik Berhasil Diperbahrui');
					window.location.href='../index.php?page=statistik';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=statistik';
				</script>
			";
		}
	break;
}
?>