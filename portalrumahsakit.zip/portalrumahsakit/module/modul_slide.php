<?php
require ("koneksi.php");

$action = $_GET['action'];

switch($action) {
	case "add" :
		
		$id = $_POST['id'];
		$ket = $_POST['ket'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/slide/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO tbl_slide (id,foto,ket) 
				 VALUES ('$id','$foto','$ket')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Slide Berhasil Ditambahkan');
					window.location.href='../index.php?page=slide';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=slide';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_slide WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Slide Telah Dihapus');
					window.location.href='../index.php?page=slide';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=slide';
				</script>
			";
		}
	break;
	
	case "update" :
		$id = $_POST['id'];
		$ket = $_POST['ket'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		
		$query = "UPDATE aset SET foto='$foto',ket='$ket' WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Aset Berhasil Diperbahrui');
					window.location.href='../index.php?page=slide';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=slide';
				</script>
			";
		}
	break;
}
?>