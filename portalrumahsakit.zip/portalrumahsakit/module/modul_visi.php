<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		
		$id = $_POST['id'];
		$judul = $_POST['judul'];
		$isi_visi = $_POST['isi_visi'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/adm/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO tbl_visi (id,judul,isi_visi,foto) 
				  VALUES ('$id','$judul','$isi_visi','$foto')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('visi Berhasil Ditambahkan');
					window.location.href='../index.php?page=visi';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=visi';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_visi WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('visi berhasil Dihapus');
					window.location.href='../index.php?page=visi';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=visi';
				</script>
			";
		}
	break;
	
	case "update" :
	
		$id = $_POST['id'];
		$judul = $_POST['judul'];
		$isi_visi = $_POST['isi_visi'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";

		move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE tbl_visi SET judul='$judul',isi_visi='$isi_visi',foto='$foto' WHERE id='$id'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('visi Berhasil Diperbarui');
					window.location.href='../index.php?page=visi';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=visi';
				</script>
			";
		}
	break;
}
?>