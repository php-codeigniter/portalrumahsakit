<?php
session_start();
require ("koneksi.php");

$user = $_POST['user'];
$pass = $_POST['pass'];
$enk = md5($pass);
$cek_user = mysql_query("SELECT * FROM tbl_admin WHERE user = '$user'");
$jumlah = mysql_num_rows($cek_user);
$hasil = mysql_fetch_array($cek_user);

if( $jumlah == 0){
	echo"
		<script type='text/javascript'>
		alert('User Belum Ada');
		window.location.href='../login.php';
		</script>
	";
} else {
if($enk <> $hasil['pass']) {
echo "
		<script type='text/javascript'>
		alert('Password Anda Salah');
		window.location.href='../login.php';
		</script>
	";
} else {
$_SESSION['user'] = $hasil['user'];
$_SESSION['type'] = $hasil['type'];
  if($hasil['type'] == "administrator"){
		header('location:../index.php');
  }else if ($hasil['type'] == "admin") {
	   header('location:../index1.php');
  } else if ($hasil['type'] == "admin1"){
	  header('location:../index2.php');
  }else if ($hasil['type'] == "kepseklas"){
	  header('location:../index3.php');
  }else if ($hasil['type'] == "kepsektor"){
	  header('location:../index4.php');
  }
  }
}
?>