<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		$idlokasi = $_POST['idlokasi'];
		$nama = $_POST['nama'];
		$lat = $_POST['lat'];
		$ing = $_POST['ing'];
		
		$query = "INSERT INTO lokasi (idlokasi,nama,lat,ing) 
				  VALUES ('$idlokasi','$nama','$lat','$ing')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data lokasi Berhasil Ditambahkan');
					window.location.href='../index.php?page=lokasi';
					window.location.href='../home.php?menu=lokasi';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=lokasi';
				</script>
			";
		}
	break;

	case "delete" :
		
		$idlokasi = $_GET['idlokasi'];
		$query = "DELETE FROM lokasi WHERE idlokasi='$idlokasi'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Nama Lokasi Berhasil Dihapus');
					window.location.href='../index.php?page=lokasi';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=lokasi';
				</script>
			";
		}
	break;
	
	case "update" :
		
		$idlokasi = $_POST['idlokasi'];
		$nama = $_POST['nama'];
		$lat = $_POST['lat'];
		$ing = $_POST['ing'];
		
		$query = "UPDATE lokasi SET nama='$nama',lat='$lat',ing='$ing' WHERE idlokasi='$idlokasi'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Lokasi Berhasil Diperbahrui');
					window.location.href='../index.php?page=lokasi';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=lokasi';
				</script>
			";
		}
	break;
}
?>