<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		
		$id = $_POST['id'];
		$judul = $_POST['judul'];
		$isi_struktural = $_POST['isi_struktural'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/adm/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO tbl_struktural (id,judul,isi_struktural,foto) 
				  VALUES ('$id','$judul','$isi_struktural','$foto')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('struktural Berhasil Ditambahkan');
					window.location.href='../index.php?page=struktural';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=struktural';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_struktural WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('struktural berhasil Dihapus');
					window.location.href='../index.php?page=struktural';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=struktural';
				</script>
			";
		}
	break;
	
	case "update" :
	
		$id = $_POST['id'];
		$judul = $_POST['judul'];
		$isi_struktural = $_POST['isi_struktural'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/adm/$foto";

		move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE tbl_struktural SET judul='$judul',isi_struktural='$isi_struktural',foto='$foto' WHERE id='$id'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('struktural Berhasil Diperbarui');
					window.location.href='../index.php?page=struktural';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=struktural';
				</script>
			";
		}
	break;
}
?>