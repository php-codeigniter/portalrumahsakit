<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		
		$id = $_POST['id'];
		$judul = $_POST['judul'];
		$isi_profile = $_POST['isi_profile'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/adm/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO tbl_profile (id,judul,isi_profile,foto) 
				  VALUES ('$id','$judul','$isi_profile','$foto')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Profile Berhasil Ditambahkan');
					window.location.href='../index.php?page=profile';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=profile';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_profile WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Profile berhasil Dihapus');
					window.location.href='../index.php?page=profile';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=profile';
				</script>
			";
		}
	break;
	
	case "update" :
	
		$id = $_POST['id'];
		$judul = $_POST['judul'];
		$isi_profile = $_POST['isi_profile'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/adm/$foto";

		move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE tbl_profile SET judul='$judul',isi_profile='$isi_profile',foto='$foto' WHERE id='$id'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('Profile Berhasil Diperbarui');
					window.location.href='../index.php?page=profile';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=profile';
				</script>
			";
		}
	break;
}
?>