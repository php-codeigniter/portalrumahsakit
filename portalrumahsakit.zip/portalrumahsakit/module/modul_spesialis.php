<?php 
require ("koneksi.php");

$action = $_GET['action'];

switch($action) {
	case "add" :
		$id_spes = $_POST['id_spes'];
		$nama_spes = $_POST['nama_spes'];		
		$query = "INSERT INTO tbl_spesialis (id_spes,nama_spes) 
				  VALUES ('$id_spes','$nama_spes')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Kecamatan Berhasil Ditambahkan');
					window.location.href='../index.php?page=spesialis';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=spesialis';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id_spes = $_GET['id_spes'];
		$query = "DELETE FROM tbl_spesialis WHERE id_spes='$id_spes'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Nama Spesialis Berhasil Dihapus');
					window.location.href='../index.php?page=spesialis';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=spesialis';
				</script>
			";
		}
	break;
	
	case "update" :

		$nama_spes = $_POST['nama_spes'];
		$id_spes = $_POST['id_spes'];
	
		$query = "UPDATE tbl_spesialis SET nama_spes='$nama_spes' WHERE id_spes='$id_spes'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Nama Spesialis Berhasil Diperbahrui');
					window.location.href='../index.php?page=spesialis';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=spesialis';
				</script>
			";
		}
	break;
}
?>