<?php
require ("koneksi.php");

$action = $_GET['action'];

switch($action) {
	case "add" :
		
		$user = $_POST['user'];
		$pass = md5['pass'];
		$type = $_POST['type'];
		$query = "INSERT INTO admin (user,pass,type) 
				 VALUES ('$user','$pass','$type')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Aset Berhasil Ditambahkan');
					window.location.href='../index.php?page=user';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=user';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM admin WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Aset Telah Dihapus');
					window.location.href='../index.php?page=user';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=user';
				</script>
			";
		}
	break;
	
	case "update" :
		$id = $_POST['id'];
		$user = $_POST['user'];
		$pass = md5($pass);
		$type = $_POST['type'];	
		$query = "UPDATE admin SET user='$user',pass='$pass',type='$type' WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Aset Berhasil Diperbahrui');
					window.location.href='../index.php?page=user';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=user';
				</script>
			";
		}
	break;
}
?>