<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		
		$id_pelayanan = $_POST['id_pelayanan'];
		$kategori = $_POST['kategori'];
		$judul = $_POST['judul'];
		$isi_berita = $_POST['isi_berita'];
		$tanggal = date('Y-m-d');
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/pelayanan/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO pelayanan (id_pelayanan,kategori,judul,isi_berita,tanggal,foto) 
				  VALUES ('$id_pelayanan','$kategori','$judul','$isi_berita','$tanggal','$foto')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Pelayanan Berhasil Ditambahkan');
					window.location.href='../index.php?page=pelayanan';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=pelayanan';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id_pelayanan = $_GET['id_pelayanan'];
		$query = "DELETE FROM berita WHERE id_pelayanan='$id_pelayanan'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Pelayanan berhasil Dihapus');
					window.location.href='../index.php?page=pelayanan';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=pelayanan';
				</script>
			";
		}
	break;
	
	case "update" :
	
		$id_pelayanan = $_POST['id_pelayanan'];
		$kategori = $_POST['kategori'];
		$judul = $_POST['judul'];
		$isi_berita = $_POST['isi_berita'];
		$tanggal = date('Y-m-d');
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/pelayanan/$foto";

		move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE pelayanan SET kategori='$kategori',judul='$judul',isi_berita='$isi_berita',tanggal='$tanggal',foto='$foto' WHERE id_pelayanan='$id_pelayanan'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('Pelayanan Berhasil Diperbarui');
					window.location.href='../index.php?page=pelayanan';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=pelayanan';
				</script>
			";
		}
	break;
}
?>