<?php error_reporting(0);
require ("koneksi.php");

$action = $_GET['action'];

switch($action) {
	case "add" :
		$id = $_POST['id'];
		$nama_kat = $_POST['nama_kat'];
		$ket_kat = $_POST['ket_kat'];
		
	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO tbl_kategori (id,nama_kat,ket_kat) 
				  VALUES ('$id','$nama_kat','$ket_kat')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Kategori Berhasil Ditambahkan');
					window.location.href='../index.php?page=kategori';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=kategori';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_kategori WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Nama Kategori Berhasil Dihapus');
					window.location.href='../index.php?page=kategori';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=kategori';
				</script>
			";
		}
	break;
	
	case "update" :

		$nama_kat = $_POST['nama_kat'];
		$id = $_POST['id'];
		

	    move_uploaded_file($lokasi_file,$direktori); 
		
		$query = "UPDATE tbl_kategori SET nama_kat='$nama_kat' WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Kategori Berhasil Diperbahrui');
					window.location.href='../index.php?page=kategori';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=kategori';
				</script>
			";
		}
	break;
}
?>