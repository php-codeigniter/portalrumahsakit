<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		
		$kode = $_POST['kode'];
		$nama = $_POST['nama'];
		$tempat_lahir = $_POST['tempat_lahir'];
		$tgl_lahir = $_POST['tgl_lahir'];
		$pekerjaan = $_POST['pekerjaan'];
		$penghasilan = $_POST['penghasilan'];
		$id_prov = $_POST['id_prov'];
		$id_kab = $_POST['id_kab'];
		$id_kec = $_POST['id_kec'];
		$alamat = $_POST['alamat'];
		$telp = $_POST['telp'];
		$user = $_POST['user'];
		$pass = $_POST['pass'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";

	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO tbl_data (kode,nama,tempat_lahir,tgl_lahir,pekerjaan,penghasilan,id_prov,id_kab,id_kec,alamat,telp,foto,user,pass) 
				  VALUES ('$kode','$nama','$tempat_lahir','$tgl_lahir','$pekerjaan','$penghasilan','$id_prov','$id_kab','$id_kec','$alamat','$telp','$foto','$user','$pass')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Pengguna Harisan Berhasil Ditambahkan');
					window.location.href='../index.php?page=datapeg';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=datapeg';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM tbl_data WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Pengguna Harisan berhasil Dihapus');
					window.location.href='../index.php?page=datapeg';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=datapeg';
				</script>
			";
		}
	break;
	
	case "update" :
		$id = $_POST['id'];
		$kode = $_POST['kode'];
		$nama = $_POST['nama'];
		$tempat_lahir = $_POST['tempat_lahir'];
		$tgl_lahir = $_POST['tgl_lahir'];
		$pekerjaan = $_POST['pekerjaan'];
		$penghasilan = $_POST['penghasilan'];
		$id_prov = $_POST['id_prov'];
		$id_kab = $_POST['id_kab'];
		$id_kec = $_POST['id_kec'];
		$alamat = $_POST['alamat'];
		$telp = $_POST['telp'];
		$user = $_POST['user'];
		$pass = $_POST['pass'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";
		
		move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE tbl_data SET kode='$kode',nama='$nama',tempat_lahir='$tempat_lahir',tgl_lahir='$tgl_lahir',pekerjaan='$pekerjaan',penghasilan='$penghasilan',id_prov='$id_prov',id_kab='$id_kab',id_kec='$id_kec',alamat='$alamat',telp='$telp',user='$user',foto='$foto',pass='$pass' WHERE id='$id'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('Pengguna Harisan Berhasil Diperbarui');
					window.location.href='../index.php?page=datapeg';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=datapeg';
				</script>
			";
		}
	break;
}
?>