<?php
require ("koneksi.php");
$action = $_GET['action'];
switch($action) {
	case "add" :
		$id = $_POST['id'];
		$nama_dok = $_POST['nama_dok'];
		$jam_kerja = $_POST['jam_kerja'];
		$id_spes = $_POST['id_spes'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";
		
	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "INSERT INTO dokter (id,nama_dok,jam_kerja,id_spes,foto) 
				  VALUES ('$id','$nama_dok','$jam_kerja','$id_spes','$foto')";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Dokter Berhasil Ditambahkan');
					window.location.href='../index.php?page=dokter';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=dokter';
				</script>
			";
		}
	break;

	case "delete" :
		
		$id = $_GET['id'];
		$query = "DELETE FROM dokter WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Nama dokter Berhasil Dihapus');
					window.location.href='../index.php?page=dokter';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=dokter';
				</script>
			";
		}
	break;
	
	case "update" :
		
		$id = $_POST['id'];
		$nama_dok = $_POST['nama_dok'];
		$jam_kerja = $_POST['jam_kerja'];
		$id_spes = $_POST['id_spes'];
		$lokasi_file = $_FILES['foto']['tmp_name'];
		$tipe_file   = $_FILES['foto']['type'];
		$foto   = $_FILES['foto']['name'];
		$direktori   = "../foto/$foto";
		
	    move_uploaded_file($lokasi_file,$direktori); 
		$query = "UPDATE dokter SET nama_dok='$nama_dok',jam_kerja='$jam_kerja',id_spes='$id_spes',foto='$foto' WHERE id='$id'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Dokter Berhasil Diperbahrui');
					window.location.href='../index.php?page=dokter';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=dokter';
				</script>
			";
		}
	break;
}
?>