
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Data lokasi</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->


 <div class="row">

 

                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DataTables Advanced Data lokasi
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>NAMA LOKASI</th>
                                       
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   
		
									
	  <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM lokasi";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
			{
			echo "
					<tr class='odd gradeX'>
						<td class='center'>" .$data['idlokasi']. "</td>
						<td class='center'>" .$data['nama']. "</td>
					
						<td class='center'>
								<div class='panel-body'>
												<button class='btn btn-info'><a href='index.php?page=tampil_lokasi&idlokasi=".$data['idlokasi']."'>lacak lokasi</a></button>

						</td>
						
						
						
								
						
					</tr> ";
			}
		
		?>
      
                               </tbody>
                            </table>
						</div>
					</div>
				</div>
			</div>
			</div>
			
			