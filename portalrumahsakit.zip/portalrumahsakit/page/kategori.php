


<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Master Kategori</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->


 <div class="row">
  <div class="col-lg-6">
                  
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Button trigger modal -->
                            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                                ADD +
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <form method="post" action="module/modul_kategori.php?action=add" id="tab" enctype="multipart/form-data">
								<div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Add +</h4> 
                                         </div>
										<div class="modal-header">
										 <div class="form-group">
                                            <input class="form-control" type="hidden" name="id"  id="id" value="<?php echo $_SESSION['id'];?>" placeholder="Masukkan ID " required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
                                        </div>
		                                 <div class="form-group">
                                            <label>Kategori</label>
                                            <input class="form-control" name="nama_kat" id="nama_kat" <?php echo $_SESSION['nama_kat'];?>"  placeholder="Masukkan Kategori" required oninvalid="this.setCustomValidity('data tidak boleh kosong')" oninput="setCustomValidity('')">
                                        </div>
                                        </div>
                                    
                                        <div class="modal-footer">
										
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                            <input type="submit" name="submit" value="Simpan" class="btn btn-primary"></button>
                                        </div>
										  </form>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
							
							
							
							
							
							
                        </div>
                        <!-- .panel-body -->
                   
                    </div>
 
 
 
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DataTables Advanced Master Kategori
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Kategori</th>   
                                    </tr>
                                </thead>
                                <tbody>
                                   
									
									
	  <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM tbl_kategori";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
			{
			echo "
					<tr class='odd gradeX'>
						<td class='center'>" .$data['id']. "</td>
						<td class='center'>" .$data['nama_kat']. "</td>		
					</tr>";
			}
		
		?>
      
                                </tbody>
                            </table>
						</div>
					</div>
				</div>
			</div>
			</div>
	