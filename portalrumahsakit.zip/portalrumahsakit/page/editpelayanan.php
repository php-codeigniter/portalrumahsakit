
  <div id="page-wrapper">
           
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Pelayanan 
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							<?php
			$id_pelayanan = $_GET['id_pelayanan'];
			$query = "SELECT pelayanan.id_pelayanan,pelayanan.kategori,pelayanan.judul,pelayanan.isi_berita,pelayanan.tanggal,pelayanan.foto,tbl_kategori.nama_kat FROM pelayanan LEFT JOIN tbl_kategori ON pelayanan.kategori = tbl_kategori.id ORDER BY pelayanan.id_pelayanan";
			$result = mysql_query($query);
			$data = mysql_fetch_array($result);
			?>
                                <form method="post" action="module/modul_pelayanan.php?action=update" id="tab" enctype="multipart/form-data">
                                  
                            <!-- Nav tabs -->
                            <ul class="nav nav-pills">
                                <li class="active"><a href="#home-pills" data-toggle="tab">Kategori</a>
                                </li>
                                <li><a href="#profile-pills" data-toggle="tab">Judul</a>
                                </li>                               
                                <li><a href="#settings-pills" data-toggle="tab">Foto</a>
                                </li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="home-pills">
										<div class="form-group">
                                            <label>Kategori</label>
											<select name="kategori" id="kategori" class="form-control" onchange="pilih_prov(this.value);">
													<option value="">- Pilih Kategori -</option>
															<?php
															$sel_kat = "SELECT id, nama_kat FROM tbl_kategori ORDER BY nama_kat";
															$q=mysql_query($sel_kat);
															while($data_kat=mysql_fetch_array($q)){
   
														
															echo'<option value="'.$data_kat["id"].'">'.$data_kat["nama_kat"] .'</option>';
																}
															?>
				                            </select>  
											&nbsp;&nbsp;<img src="loading.gif" width="30" id="imgLoad" style="display:none;" />											
										</div>
											<div class="form-group">
                                            <label>Judul</label>
                                            <textarea class="form-control"  name="judul" id="judul" value="<?php $data['judul']; ?>"> </textarea>
                                        </div>
                                </div>
                                <div class="tab-pane fade" id="profile-pills">
                                  		<div class="form-group">
                                            <label>Isi Berita</label>
                                            <textarea class="form-control"  name="isi_berita" id="isi_berita" value="<?php $data['isi_berita']; ?>"> </textarea>
                                        </div>
		                              
								  </div>
                                <div class="tab-pane fade" id="settings-pills">
		                                <label>Foto</label>
										<input type="file" name="foto" class="input-xlarge"></br>
													*kosongkan bila tidak ada foto
													</br>
													 <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                                            <input type="submit" name="submit" value="Simpan" class="btn btn-primary"></button>
											 <input type="hidden" name="id" class="input-xlarge" value="<?php echo $data['id_pelayanan']; ?>">
											</div>
											
								   </div>
                            </div>
							</form>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->

	        <!-- /.panel-body -->
                    </div>
          
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="http://localhost/piutang/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="http://localhost/piutang/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="http://localhost/piutang/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="http://localhost/piutang/dist/js/sb-admin-2.js"></script>

	
	