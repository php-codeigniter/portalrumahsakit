
			
		<?php
		 error_reporting(0);
include "module/koneksi.php";
			$id = $_GET['id'];
			$query = "SELECT * FROM admin where id = '$id'";
			$gambo = mysql_query($query);
			$data = mysql_fetch_array($gambo);
		?>      
					<div class="row col-md-6">
					<form method="post" action="module/modul_user.php?action=update" id="tab">
						<label>id</label><br>
						<input type="text" class="form-control" name="id" value="<?php echo $data['id'];?>" required><br>
						<label>User</label><br>
						<input type="text" class="form-control" name="user" value="<?php echo $data['user'];?>" required><br>
						<label>Pass</label><br>
						<input type="password" class="form-control" name="pass" value="<?php echo $data['pass']; ?>" required><br>
						<label>Status</label><br>
						<select name="type" required class="form-control"> 
						 
							<option value="<?php echo $data['type']; ?>"><?php echo $data['type']; ?></option>
							<option value="administrator">YAYASAN</option> 
							<option value="admin">SMK LAMASI</option> 
							<option value="admin1">SMK TORAJA</option> 
							<option value="kepseklas">KEPSEK LAMASI</option> 
							<option value="kepsektor">KEPSEK TORAJA</option> 
						</select><br>
						<input type="submit" name="form-update" value="Simpan" class="btn btn-success">
					</form>
					</div>
					<div class="row col-md-12"><hr></div>
	

