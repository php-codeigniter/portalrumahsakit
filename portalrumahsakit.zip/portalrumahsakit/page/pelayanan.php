
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Data Pelayanan</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->


 <div class="row">
  <div class="col-lg-6">
                  
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Button trigger modal -->
                            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#Tambahdata">
                                Add Pelayanan +
                            </button>
							 <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#Tambahpiutang">
                                Add No available +
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="Tambahdata" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <form method="post" action="module/modul_pelayanan.php?action=add" id="tab" enctype="multipart/form-data">
								<div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Add Pelayanan +</h4> 
                                         </div>
										<div class="modal-header">
										 <div class="form-group">
                                            <input class="form-control" type="hidden" name="id_pelayanan" id="id_pelayanan" maxlength="6" onKeyPress="return goodchars(event,'0123456789',this)" placeholder="Masukkan Kode">
                                        </div>
										
										<div class="form-group">
                                            <label>Kategori Pelayanan</label>
											<select name="kategori" id="kategori" class="form-control" onchange="pilih_prov(this.value);">
													<option value="">- Pilih Kategori -</option>
															<?php
															$sel_kat = "SELECT id, nama_pel FROM tbl_katpel ORDER BY nama_pel";
															$q=mysql_query($sel_kat);
															while($data_pel=mysql_fetch_array($q)){
   
														
															echo'<option value="'.$data_pel["id"].'">'.$data_pel["nama_pel"] .'</option>';
																}
															?>
				                            </select>  
											&nbsp;&nbsp;<img src="loading.gif" width="30" id="imgLoad" style="display:none;" />											
										</div>
										
										<div class="form-group">
                                            <label>Judul</label>
                                            <textarea class="form-control" name="judul" id="judul"  placeholder="Isi judul berita"></textarea>
                                        </div>
									
		                                <div class="form-group">
                                            <label>Berita</label>
											<textarea class="form-control" name="isi_berita" id="isi_berita"  placeholder="Isi berita"></textarea>  
											</div>					
		                                <label>Foto</label>
										<input type="file" name="foto" class="input-xlarge"></br>
													*kosongkan bila tidak ada foto
													</br>
                                        </div>
                                    
                                        <div class="modal-footer">
										
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <input type="submit" name="submit" value="Simpan" class="btn btn-primary"></button>
                                        </div>
										  </form>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
							
							
							
							
							
							
                        </div>
                        <!-- .panel-body -->
                   
                    </div>
 
 
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DataTables Advanced Data Pelayanan
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Kategori</th>
                                        <th>Judul</th>
                                        <th>Isi</th>
                                        <th>Tanggal</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   
									
									
	  <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT pelayanan.id_pelayanan,pelayanan.kategori,pelayanan.judul,pelayanan.isi_berita,pelayanan.tanggal,pelayanan.foto,tbl_katpel.nama_pel FROM pelayanan LEFT JOIN tbl_katpel ON pelayanan.kategori = tbl_katpel.id ORDER BY pelayanan.id_pelayanan";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
			{
			echo "
					<tr class='odd gradeX'>
						<td class='center'>" .$data['nama_pel']. "</td>
						<td class='center'>" .$data['judul']. "</td>
						<td class='center'>" .$data['isi_berita']. "</td>
						<td class='center'>" .$data['tanggal']. "</td>
						<td class='center'>
								<a href='index.php?page=editpelayanan&id=".$data['id_pelayanan']."'><i class='icon-pencil'></i></a>
								<div class='panel-body'>
				
							<button class='btn btn-info' data-toggle='modal' data-target='#view".$data['id_pelayanan']."'>
                                View
                            </button>
							</a>
							<a href='index.php?page=editpelayanan&id=".$data['id_pelayanan']."'><button class='btn btn-warning' data-toggle='modal'>
                                Edit
                            </button>
							</a>
							
						
							<a href='#".$data['id_pelayanan']."'><button class='btn btn-danger' data-toggle='modal' data-target='#delete".$data['id']."'>
                                Delete
                            </button></a>
							
							<div class='modal fade' id='delete".$data['id_pelayanan']."' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                                <form method='post' action='module/modul_pelayanan.php?action=delete&id= ".$data['id_pelayanan']."'>
								<div class='modal-dialog'>
                                    <div class='modal-content'>
                                        <div class='modal-header'>
                                         </div>
										<div class='modal-header'>
		                                 <div class='form-group'>
                                            <label>Apakah anda yakin menghapus data ini ?</label>
                                        </div>
                                        </div>
                                    
                                        <div class='modal-footer'>
										
                                            <button type='button' class='btn btn-danger' data-dismiss='modal'>Tidak</button>
                                            <input type='submit' name='submit' value='Ya' class='btn btn-primary'></button>
                                        </div>
										  </form>
                                    </div>
                                    
                                </div>
				
                            </div>
                            </div>
							
							
							
							<div class='modal fade' id='piutang".$data['kode']."' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                                <form method='post' action='index.php?page=detailpiutang'>
								<div class='modal-dialog'>
                                    <div class='modal-content'>
                                        <div class='modal-header'>
                                         </div>
										<div class='modal-header'>
		                                 <div class='form-group'>
                                            <label>Apakah anda Ingin Melihat detail Piutang " .$data['nama']. " ?</label>
                                        </div>
                                        </div>
                                    
                                        <div class='modal-footer'>
										
                                            <button type='button' class='btn btn-danger' data-dismiss='modal'>Tidak</button>
                                            <input type='submit' name='submit' value='Ya' class='btn btn-primary'></button>
											<input type='hidden' name='kodepel' id='kodepel'  value='".$data['kode']."'>
                                        </div>
										  </form>
                                    </div>
                                    
                                </div>
				
                            </div>
                            </div>
							
						</td>
						
						
						

						 <div class='modal fade' id='view".$data['id_pelayanan']."' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                                <form method='post' action='module/modul_data.php?action=update&id= ".$data['id_pelayanan']."' id='tab' enctype='multipart/form-data'>
								<div class='modal-dialog'>
                                     <div class='modal-content'>
                                        <div class='modal-header'>
                                            <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
                                            <h4 class='modal-title' id='myModalLabel'>View Data+</h4> 
											<h2 align='center'><strong><img src='foto/".$data['foto']. "'  style='border-radius: 3px;' align='center' width='250' height='250' /> </strong></h2>
                                         </div>
										<div class='modal-header'>
										 <div class='form-group'>
                                            <label>Tanggal</label>
                                            <input class='form-control' name='tanggal' id='tanggal' value='".$data['tanggal']."' disabled>
                                        </div>
										
										<div class='form-group'>
                                            <label>Kategori</label>
                                            <input class='form-control' name='kategori' id='kategori'  value='".$data['nama_pel']."' disabled>
                                        </div>
										<div class='form-group'>
                                            <label>Judul Berita</label>
                                            <input class='form-control' name='judul' id='judul'  value='".$data['judul']."' disabled>
                                        </div>
										<div class='form-group'>
                                            <label>Isi Berita</label>
                                            <textarea class='form-control' name='isi_berita' id='isi_berita'  value='".$data['isi_berita']."' disabled></textarea>
                                        </div>
									
                                        </div>
                                    
                                        <div class='modal-footer'>
										
                                            <button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button>
                                        </div>
										  </form>
                                    </div>
                                  
                                </div>
                              
                            </div>
								
						
					</tr> ";
			}
		
		?>
      
                               </tbody>
                            </table>
						</div>
					</div>
				</div>
			</div>
			</div>
			
			