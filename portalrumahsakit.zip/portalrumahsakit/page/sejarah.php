
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Data Sejarah</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->


 <div class="row">
  <div class="col-lg-6">
                  
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <!-- Button trigger modal -->
                            <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#Tambahdata">
                                Add Sejarah +
                            </button>
							 <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#Tambahpiutang">
                                Add No available +
                            </button>
                            <!-- Modal -->
                            <div class="modal fade" id="Tambahdata" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <form method="post" action="module/modul_sejarah.php?action=add" id="tab" enctype="multipart/form-data">
								<div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Add Sejarah +</h4> 
                                         </div>
										<div class="modal-header">
										 <div class="form-group">
                                            <input class="form-control" type="hidden" name="id" id="id" maxlength="6" onKeyPress="return goodchars(event,'0123456789',this)" placeholder="Masukkan Kode">
                                        </div>
										
										<div class="form-group">
                                            <label>Judul Sejarah</label>
                                            <textarea class="form-control" name="judul" id="judul"  placeholder="Isi judul sejarah"></textarea>
                                        </div>
									
		                                <div class="form-group">
                                            <label>Sejarah</label>
											<textarea class="form-control" name="isi_sejarah" id="isi_sejarah"  placeholder="Isi sejarah"></textarea>  
											</div>					
		                                <label>Foto</label>
										<input type="file" name="foto" class="input-xlarge"></br>
													*kosongkan bila tidak ada foto
													</br>
                                        </div>
                                    
                                        <div class="modal-footer">
										
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <input type="submit" name="submit" value="Simpan" class="btn btn-primary"></button>
                                        </div>
										  </form>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
							
							
							
							
							
							
                        </div>
                        <!-- .panel-body -->
                   
                    </div>
 
 
 
  <div class="modal fade" id="Tambahpiutang" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <form method="post" action="module/modul_piutang.php?action=add" id="tab" enctype="multipart/form-data">
								<div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Add Piutang +</h4> 
                                         </div>
										<div class="modal-header">
										 <div class="form-group">
                                            <label>Kode Pelanggan</label>
                                            <input class="form-control" name="kode" id="kode" placeholder="Masukkan Kode Pelanggan" onkeyup="isi_otomatis()" id="kode" autocomplete="off" maxlength="16" onKeyPress="return goodchars(event,'0123456789',this)">
                                        </div>
								
										<div class="form-group">
                                            <label>Tanggal</label>
                                            <input class="form-control" type="date" name="tgl_bayar" id="tgl_bayar" >
                                        </div>
										
										<div class="form-group">
                                            <label>Nama Barang</label>
                                            <input class="form-control"  name="nama_utang" id="nama_utang" placeholder="Masukkan Nama Barang">
                                        </div>
										<div class="form-group">
                                            <label>Harga Barang</label>
                                            <input class="form-control" type="number" name="jumlah" id="jumlah" placeholder="Masukkan Harga Barang" maxlength="22" onKeyPress="return goodchars(event,'0123456789',this)" required>
                                        </div>
										
                                        <div class="modal-footer">
										
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            <input type="submit" name="submit" value="Simpan" class="btn btn-primary"></button>
                                        </div>
										  </form>
				
										  
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
							
                        </div>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DataTables Advanced Data Sejarah
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Judul</th>
                                        <th>Isi</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   
									
									
	  <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM tbl_sejarah ORDER BY tbl_sejarah.id";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
			{
			echo "
					<tr class='odd gradeX'>
						<td class='center'>" .$data['judul']. "</td>
						<td class='center'>" .$data['isi_sejarah']. "</td>
						<td class='center'>
								<a href='index.php?page=editprofil&id=".$data['id']."'><i class='icon-pencil'></i></a>
								<div class='panel-body'>
				
							<button class='btn btn-info' data-toggle='modal' data-target='#view".$data['id']."'>
                                View
                            </button>
							</a>
							<a href='index.php?page=editsejarah&id=".$data['id']."'><button class='btn btn-warning' data-toggle='modal'>
                                Edit
                            </button>
							</a>
							
						
							<a href='#".$data['id']."'><button class='btn btn-danger' data-toggle='modal' data-target='#delete".$data['id']."'>
                                Delete
                            </button></a>
							
							<div class='modal fade' id='delete".$data['id']."' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                                <form method='post' action='module/modul_sejarah.php?action=delete&id= ".$data['id']."'>
								<div class='modal-dialog'>
                                    <div class='modal-content'>
                                        <div class='modal-header'>
                                         </div>
										<div class='modal-header'>
		                                 <div class='form-group'>
                                            <label>Apakah anda yakin menghapus data ini ?</label>
                                        </div>
                                        </div>
                                    
                                        <div class='modal-footer'>
										
                                            <button type='button' class='btn btn-danger' data-dismiss='modal'>Tidak</button>
                                            <input type='submit' name='submit' value='Ya' class='btn btn-primary'></button>
                                        </div>
										  </form>
                                    </div>
                                    
                                </div>
				
                            </div>
                            </div>
							
							
							
							<div class='modal fade' id='piutang".$data['kode']."' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                                <form method='post' action='index.php?page=detailpiutang'>
								<div class='modal-dialog'>
                                    <div class='modal-content'>
                                        <div class='modal-header'>
                                         </div>
										<div class='modal-header'>
		                                 <div class='form-group'>
                                            <label>Apakah anda Ingin Melihat detail Piutang " .$data['nama']. " ?</label>
                                        </div>
                                        </div>
                                    
                                        <div class='modal-footer'>
										
                                            <button type='button' class='btn btn-danger' data-dismiss='modal'>Tidak</button>
                                            <input type='submit' name='submit' value='Ya' class='btn btn-primary'></button>
											<input type='hidden' name='kodepel' id='kodepel'  value='".$data['kode']."'>
                                        </div>
										  </form>
                                    </div>
                                    
                                </div>
				
                            </div>
                            </div>
							
						</td>
						
						
						

						 <div class='modal fade' id='view".$data['id']."' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                                <form method='post' action='module/modul_data.php?action=update&id= ".$data['id']."' id='tab' enctype='multipart/form-data'>
								<div class='modal-dialog'>
                                     <div class='modal-content'>
                                        <div class='modal-header'>
                                            <button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button>
                                            <h4 class='modal-title' id='myModalLabel'>View Data+</h4> 
											<h2 align='center'><strong><img src='foto/".$data['foto']. "'  style='border-radius: 3px;' align='center' width='250' height='250' /> </strong></h2>
                                         </div>
										<div class='modal-header'>
										 <div class='form-group'>
										<div class='form-group'>
                                            <label>Kategori</label>
                                            <input class='form-control' name='kategori' id='kategori'  value='".$data['nama_kat']."' disabled>
                                        </div>
										<div class='form-group'>
                                            <label>Judul sejarah</label>
                                            <input class='form-control' name='judul' id='judul'  value='".$data['judul']."' disabled>
                                        </div>
										<div class='form-group'>
                                            <label>Isi sejarah</label>
                                            <textarea class='form-control' name='isi_sejarah' id='isi_sejarah'  value='".$data['isi_sejarah']."' disabled></textarea>
                                        </div>
									
                                        </div>
                                    
                                        <div class='modal-footer'>
										
                                            <button type='button' class='btn btn-danger' data-dismiss='modal'>Close</button>
                                        </div>
										  </form>
                                    </div>
                                  
                                </div>
                              
                            </div>
								
						
					</tr> ";
			}
		
		?>
      
                               </tbody>
                            </table>
						</div>
					</div>
				</div>
			</div>
			</div>
			
			