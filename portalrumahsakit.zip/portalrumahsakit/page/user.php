
	
	<div class="container">
		<?php error_reporting(0);
			$q = mysql_query("select*from admin");
			$j = mysql_num_rows($q);
		?>
		<h4>Daftar user Masuk (<?php echo ($j>0)?$j:0; ?>)</h4>
		<a class="btn btn-sm btn-primary" href="#">Tambah User</a>
		
		
		<table class="table table-striped table-hove"> 
			<thead> 
				<tr> 
					<th>#</th> 
					<th>User</th> 
					<th>Pass</th> 
					<th>type</th> 
					<th>*</th> 
				</tr> 
			</thead> 
			<tbody> 
				

			
			
		<?php while($data=mysql_fetch_object($q)){ ?> 
				<tr> 
					<th scope="row"><?php echo $no++; ?></th> 
					<td><?php echo $data->user ?></td> 
					<td><?php echo $data->pass ?></td> 
					<td><?php echo $data->type ?></td> 
					<td>
						<a class="btn btn-sm btn-success" href="index.php?page=edit_user&id=&id=<?php echo $data->id ?>">edit</a>
				
					</td> 
				</tr>
		<?php } ?>
			</tbody> 
		</table> 
    </div> <!-- /container -->
	
