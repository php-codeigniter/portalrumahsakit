<h1 class="page-title">Edit Data Sejarah</h1>
        </div>
        
                <ul class="breadcrumb">
            <li><a href="index.php?page=home">Home</a> <span class="divider">/</span></li>
            <li><a href="index.php?page=penjualan">Data Sejarah</a> <span class="divider">/</span></li>
            <li class="active">Edit Data Sejarah</li>
        </ul>

        <div class="container-fluid">
            <div class="row-fluid">
         <?php
			$id = $_GET['id'];
			$query = "SELECT * FROM sejarah_yayasan where id = '$id'";
			$result = mysql_query($query);
			$data = mysql_fetch_array($result);
		?>        

	<form method="post" action="module/modul_sejarah.php?action=update" id="tab">
  <div class="well">
    <ul class="nav nav-tabs">
      <li class="active"><a href="#home" data-toggle="tab">Edit Sejarah</a></li>
    </ul>
    <div id="myTabContent" class="tab-content">
      <div class="tab-pane active in" id="home">
		
		<label>Isi Sejarah</label>
		<textarea name="profil" class="input-xlarge"><?php echo $data['isi']; ?></textarea>
		
		<input type="hidden" name="user" value="<?php echo $_SESSION['username']; ?>">
		<input type="hidden" name="id" value="<?php echo $data['id']; ?>">
		
		</br>
		<div class="btn-group">
		<div class="btn-toolbar">
		 <i class="icon-save"><input type="submit" name="submit" value="Simpan" button class="btn btn-primary"></i></button>
		
</div>
  
		
		
    </form>
      </div>
     
  </div>

</div>


</div>