                            <?php

  $carimap = mysql_query("select * from lokasi where idlokasi='$_GET[idlokasi]'");
  $dcari = mysql_fetch_array($carimap);
?>
  
<div id="page-wrapper">
          
 <div class="row">

 
 
 
 

                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            DataTables Advanced Data lokasi
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">


    <style type="text/css">
      html { height: 100% }
      body { height: 100%; }
      #map-canvas { height: 100% }
    </style>
    <!-- <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script> -->
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBzxq53hccrqVLdZ0r4W8YQ-YxD2Fm7l_8&callback=initMap"
  type="text/javascript"></script>  </head>


 
  <div id="page-wrapper" style="max-width:500px;max-height: 300px;"></div>

 

<script type="text/javascript">
        function initialize() {
    var mapOptions = {
      zoom: 15,
      center: new google.maps.LatLng(<?php echo "$dcari[lat], $dcari[ing]"; ?>)
    }
    var map = new google.maps.Map(document.getElementById('page-wrapper'),
      mapOptions);
    
    setMarkers(map, beaches);
	
  }

  var beaches = [
    ['<?php echo "$dcari[nama]"; ?>', <?php echo "$dcari[lat], $dcari[ing]"; ?>],
  ];

  function setMarkers(map, locations) {
    var shape = {
      coords: [1, 1, 1, 20, 18, 20, 18 , 1],
      type: 'poly'
    };
    var infoWindow = new google.maps.InfoWindow;
    for (var i = 0; i < locations.length; i++) {
      var beach = locations[i];
      var myLatLng = new google.maps.LatLng(beach[1], beach[2]);
      var marker = new google.maps.Marker({
        position: myLatLng,
        map: map,
        icon: beach[4],
        shape: shape,
        title: beach[0],
        zIndex: beach[3]
      });
      var html = 'Lokasi : '+beach[0]+'<br/>Latitude : '+beach[1]+'<br/>Longitude : '+beach[2]+'';
      bindInfoWindow(marker, map, infoWindow, html);
    }
  }
  
  function bindInfoWindow(marker, map, infoWindow, html) {
      google.maps.event.addListener(marker, 'click', function() {
        infoWindow.setContent(html);
        infoWindow.open(map, marker);
      });
    }

  google.maps.event.addDomListener(window, 'load', initialize);
</script>

							
							
							
							
							
						</div>
					</div>
				</div>
			</div>
			</div>
			
			