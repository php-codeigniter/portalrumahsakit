<?php 
	$menu= $_GET['menu'];
	$link= $menu;
	include("sub/$link.php"); 
?>