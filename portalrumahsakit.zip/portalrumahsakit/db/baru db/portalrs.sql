-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2017 at 04:15 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portalrs`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
`id` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `judul` text NOT NULL,
  `isi_berita` text NOT NULL,
  `tanggal` date NOT NULL,
  `foto` varchar(125) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `kategori`, `judul`, `isi_berita`, `tanggal`, `foto`) VALUES
(3, '2', 'Merupakan Anak Kandung dari Hacker Cantik', 'SaLam IT para Punggawa MAYA, KaLi ini ane bakaL mencoba mengajak agan2\r\ntuk sedikit MeLenturkan Jemari Pengetahuan Underground  Agan2 Seputar Cara Penggunaan\r\nCain & AbLeâ€¦..\r\nAne Pernah GoogLing, nyari tau tentang asaL muasaL Software Super Canggih ini,\r\ndan hasiLnya Cain AbLe Merupakan Anak Kandung dari Hacker Cantik  yang memimpin\r\n2200 Hacker Wanita Di Chinaâ€¦!!! WoWâ€¦\r\nSebut Saja â€œXIAO TIANâ€\r\nSoâ€¦ Langsung aja niiii Penampakannyaâ€¦â€¦\r\n', '2017-06-02', 'dd.jpg'),
(4, '', '3.	Untuk melakukan aksi sniffing, klik tab Sniffer', 'Hacking via LAN (snifing). Teknik nya disebut Man In The Middle attack (Apa itu?). Sniffing adalah sebuah aksi penyadapan terhadap setiap paket request dan reply di jaringan LAN. Melihat cara yang digunakan, sniffing dibagi kedalan dua kategori; passive sniffing yaitu melakukan penyadapan tanpa merubah data atau packet apapun dari jaringan sedangkan active sniffing merubah packet di jaringan atau mengirimkan packet dengan alamat MAC yang berubah-ubah secara acak dalam jumlah yang sangat banyak.\r\nActive sniffing biasanya menggunakan tool tambahan (yang biasa digunakan yaitu Etherflood), tapi kali ini kita hanya akan membahas bagaimana cara menggunakan passive sniffing dan tool yang kita gunakan adalah Cain & Abel.\r\nApa saja yang kita butuhkan?\r\n1. Software Cain & Abel, dapat di download di sini.\r\n2. Cari warnet yang rame\r\n3. Snack atau makanan ringan segukupnya Minuman.\r\n4. Apa aja yang dirasa perlu dechâ€¦\r\nTrusâ€¦.!!!! Apa saja langkah-langkah yang akan kita lakukan?\r\nLangkah-langkah yang harus dilakukan:\r\n1.	Install program Cain&Abel\r\n2.	Jalankan Cain\r\n3.	Untuk melakukan aksi sniffing, klik tab Sniffer\r\n', '2017-06-02', 'hack.jpg'),
(5, '3', 'Bagian Kesubag Kepagawaian dan Pengembangan Diklat', 'Menyembunyikan MAC Address\r\nPada pertemuan kali ini saya akan menjelaskan aplikasi sederhana yang saya dapatkan untuk menyembunyikan MAC Address kita dari gangguan user nakal yang terdapat dijaringan.\r\n\r\nUntuk menyembunyikan MAC Address saya menggunakan program Hide My MAC Address 2.1.3380.16020 yang saya download 2 hari lalu di http://www.hide-my-ip.com aplikasi ini sangat sederhana gampang untuk digunakan oleh pemula. untuk mengetahui langkah dasarnya silahkan ikuti petunjuk dibawah ini.\r\n\r\nAda dua cara kita untuk menyembunyikan MAC Address kita, yaitu\r\nCara pertama, sama sekali tidak menampilkan MAC Address kepada siapapun dijaringan.\r\nCara kedua adalah cara untuk para user Advanced, dengan cara ini kita bisa memasukan MAC Address sesuka kita atau random MAC Address, sehingga MAC Address yang terdapat dijaringan bukanlah MAC Adddress yang asli.\r\n\r\nBila anda menginginkan cara Advanced untuk menyembunyikan MAC Address anda, maka ikutilah langkah-langkah berikut :\r\nâ€¢  Jalankan program Hide My MAC Address dan centang check box Advanced User Mode\r\nâ€¢  Maka jendela program tersebut akan memanjang kebawah dan tampilan akan lebih lengkap lagi\r\nâ€¢  Pada spoof MAC Address ada 6 kotak isian yang bisa anda isi untuk menampilkan MAC Address palsu dijaringan bila MAC Address sudah diisi lalu tekan spoof dan koneksipun direstart secara otomatis. Disini MAC Address yang anda masukan merupakan MAC Address palsu untuk mengecoh jaringan.\r\nâ€¢  Bila anda susah dalam menentukan MAC Address, program ini juga mempunyai fasilitas untuk menentukan MAC Address secara otomatis. Cukup gampang anda Cuma klik tombol Random dan tekan spoof untuk menetapkannya sebagai MAC Address palsu anda.\r\n\r\nAda catatan dari saya sedikit buat Anda. Sebelum anda meng-install software tersebut. Pertama-tama anda harus download .NET Framework 2.0 sebagai pendukungnya.\r\n\r\nAnda tertarik dengan software ini silahkan download di http://www.hide-my-ip.com. untuk software pendukungnya Anda bisa download di http://www.microsoft.com.\r\nSelamat mencoba!\r\n\r\n', '2017-06-06', 'bayar.png'),
(6, '2', 'Hacker indonesia jebol bank sebanyak 201 bank ', 'Menyembunyikan MAC Address\r\nPada pertemuan kali ini saya akan menjelaskan aplikasi sederhana yang saya dapatkan untuk menyembunyikan MAC Address kita dari gangguan user nakal yang terdapat dijaringan.\r\n\r\nUntuk menyembunyikan MAC Address saya menggunakan program Hide My MAC Address 2.1.3380.16020 yang saya download 2 hari lalu di http://www.hide-my-ip.com aplikasi ini sangat sederhana gampang untuk digunakan oleh pemula. untuk mengetahui langkah dasarnya silahkan ikuti petunjuk dibawah ini.\r\n\r\nAda dua cara kita untuk menyembunyikan MAC Address kita, yaitu\r\nCara pertama, sama sekali tidak menampilkan MAC Address kepada siapapun dijaringan.\r\nCara kedua adalah cara untuk para user Advanced, dengan cara ini kita bisa memasukan MAC Address sesuka kita atau random MAC Address, sehingga MAC Address yang terdapat dijaringan bukanlah MAC Adddress yang asli.\r\n\r\nBila anda menginginkan cara Advanced untuk menyembunyikan MAC Address anda, maka ikutilah langkah-langkah berikut :\r\nâ€¢  Jalankan program Hide My MAC Address dan centang check box Advanced User Mode\r\nâ€¢  Maka jendela program tersebut akan memanjang kebawah dan tampilan akan lebih lengkap lagi\r\nâ€¢  Pada spoof MAC Address ada 6 kotak isian yang bisa anda isi untuk menampilkan MAC Address palsu dijaringan bila MAC Address sudah diisi lalu tekan spoof dan koneksipun direstart secara otomatis. Disini MAC Address yang anda masukan merupakan MAC Address palsu untuk mengecoh jaringan.\r\nâ€¢  Bila anda susah dalam menentukan MAC Address, program ini juga mempunyai fasilitas untuk menentukan MAC Address secara otomatis. Cukup gampang anda Cuma klik tombol Random dan tekan spoof untuk menetapkannya sebagai MAC Address palsu anda.\r\n\r\nAda catatan dari saya sedikit buat Anda. Sebelum anda meng-install software tersebut. Pertama-tama anda harus download .NET Framework 2.0 sebagai pendukungnya.\r\n\r\nAnda tertarik dengan software ini silahkan download di http://www.hide-my-ip.com. untuk software pendukungnya Anda bisa download di http://www.microsoft.com.\r\nSelamat mencoba!\r\n\r\n', '2017-06-06', 'ada.png'),
(7, '2', 'Indonesia Hack Paling di takuti Sedunia ', 'Menyembunyikan MAC Address\r\nPada pertemuan kali ini saya akan menjelaskan aplikasi sederhana yang saya dapatkan untuk menyembunyikan MAC Address kita dari gangguan user nakal yang terdapat dijaringan.\r\n\r\nUntuk menyembunyikan MAC Address saya menggunakan program Hide My MAC Address 2.1.3380.16020 yang saya download 2 hari lalu di http://www.hide-my-ip.com aplikasi ini sangat sederhana gampang untuk digunakan oleh pemula. untuk mengetahui langkah dasarnya silahkan ikuti petunjuk dibawah ini.\r\n\r\nAda dua cara kita untuk menyembunyikan MAC Address kita, yaitu\r\nCara pertama, sama sekali tidak menampilkan MAC Address kepada siapapun dijaringan.\r\nCara kedua adalah cara untuk para user Advanced, dengan cara ini kita bisa memasukan MAC Address sesuka kita atau random MAC Address, sehingga MAC Address yang terdapat dijaringan bukanlah MAC Adddress yang asli.\r\n\r\nBila anda menginginkan cara Advanced untuk menyembunyikan MAC Address anda, maka ikutilah langkah-langkah berikut :\r\nâ€¢  Jalankan program Hide My MAC Address dan centang check box Advanced User Mode\r\nâ€¢  Maka jendela program tersebut akan memanjang kebawah dan tampilan akan lebih lengkap lagi\r\nâ€¢  Pada spoof MAC Address ada 6 kotak isian yang bisa anda isi untuk menampilkan MAC Address palsu dijaringan bila MAC Address sudah diisi lalu tekan spoof dan koneksipun direstart secara otomatis. Disini MAC Address yang anda masukan merupakan MAC Address palsu untuk mengecoh jaringan.\r\nâ€¢  Bila anda susah dalam menentukan MAC Address, program ini juga mempunyai fasilitas untuk menentukan MAC Address secara otomatis. Cukup gampang anda Cuma klik tombol Random dan tekan spoof untuk menetapkannya sebagai MAC Address palsu anda.\r\n\r\nAda catatan dari saya sedikit buat Anda. Sebelum anda meng-install software tersebut. Pertama-tama anda harus download .NET Framework 2.0 sebagai pendukungnya.\r\n\r\nAnda tertarik dengan software ini silahkan download di http://www.hide-my-ip.com. untuk software pendukungnya Anda bisa download di http://www.microsoft.com.\r\nSelamat mencoba!\r\n\r\n', '2017-06-06', 'cek.png'),
(8, '2', 'Kategori dan Sub-Kategori Unlimited MYSQL PHP', 'Kategori. Berita dan Politik Â· The Lounge Â· Sista Â· Dota 2 Â· Liga Italia Â· Liga Inggris Â· GP Mania ... ane pengen bikin yang kayak gini pake PHP + MySQL. Topi. Kupluk ... trus cara ngitung misalnya si "celana" punya sub-kategori berapa atau celana ... KASKUS Ads - Create Your Ads / Buat Iklan Â· #2. profile- ...', '2017-06-11', 'ss.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE IF NOT EXISTS `dokter` (
`id` int(11) NOT NULL,
  `nama_dok` varchar(100) NOT NULL,
  `jam_kerja` varchar(120) NOT NULL,
  `id_spes` int(11) NOT NULL,
  `foto` varchar(220) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id`, `nama_dok`, `jam_kerja`, `id_spes`, `foto`) VALUES
(8, 'vsdfsd', ' dsfs', 3, 'a.jpg'),
(9, 'asads', 'PKL: 09:00 s/d 12:00 WIB', 2, 'hack.jpg'),
(10, 'saktiawan', 'Pkl 08:00 s/d 09:00', 3, ''),
(12, 'dr. Asmur', 'SDSDF', 6, '');

-- --------------------------------------------------------

--
-- Table structure for table `galeri`
--

CREATE TABLE IF NOT EXISTS `galeri` (
`id` int(11) NOT NULL,
  `foto` varchar(539) NOT NULL,
  `ket` varchar(123) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galeri`
--

INSERT INTO `galeri` (`id`, `foto`, `ket`) VALUES
(1, 'a.jpg', ''),
(2, 'dd.jpg', ''),
(3, 'ddddd.jpg', 'cdfd');

-- --------------------------------------------------------

--
-- Table structure for table `pelayanan`
--

CREATE TABLE IF NOT EXISTS `pelayanan` (
`id_pelayanan` int(11) NOT NULL,
  `kategori` int(11) NOT NULL,
  `judul` text NOT NULL,
  `isi_berita` text NOT NULL,
  `tanggal` date NOT NULL,
  `foto` varchar(112) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelayanan`
--

INSERT INTO `pelayanan` (`id_pelayanan`, `kategori`, `judul`, `isi_berita`, `tanggal`, `foto`) VALUES
(1, 3, 'Bagian Administrasi Kepegawaian', 'Menyembunyikan MAC Address\r\nPada pertemuan kali ini saya akan menjelaskan aplikasi sederhana yang saya dapatkan untuk menyembunyikan MAC Address kita dari gangguan user nakal yang terdapat dijaringan.\r\n\r\nUntuk menyembunyikan MAC Address saya menggunakan program Hide My MAC Address 2.1.3380.16020 yang saya download 2 hari lalu di http://www.hide-my-ip.com aplikasi ini sangat sederhana gampang untuk digunakan oleh pemula. untuk mengetahui langkah dasarnya silahkan ikuti petunjuk dibawah ini.\r\n\r\nAda dua cara kita untuk menyembunyikan MAC Address kita, yaitu\r\nCara pertama, sama sekali tidak menampilkan MAC Address kepada siapapun dijaringan.\r\nCara kedua adalah cara untuk para user Advanced, dengan cara ini kita bisa memasukan MAC Address sesuka kita atau random MAC Address, sehingga MAC Address yang terdapat dijaringan bukanlah MAC Adddress yang asli.\r\n\r\nBila anda menginginkan cara Advanced untuk menyembunyikan MAC Address anda, maka ikutilah langkah-langkah berikut :\r\nâ€¢  Jalankan program Hide My MAC Address dan centang check box Advanced User Mode\r\nâ€¢  Maka jendela program tersebut akan memanjang kebawah dan tampilan akan lebih lengkap lagi\r\nâ€¢  Pada spoof MAC Address ada 6 kotak isian yang bisa anda isi untuk menampilkan MAC Address palsu dijaringan bila MAC Address sudah diisi lalu tekan spoof dan koneksipun direstart secara otomatis. Disini MAC Address yang anda masukan merupakan MAC Address palsu untuk mengecoh jaringan.\r\nâ€¢  Bila anda susah dalam menentukan MAC Address, program ini juga mempunyai fasilitas untuk menentukan MAC Address secara otomatis. Cukup gampang anda Cuma klik tombol Random dan tekan spoof untuk menetapkannya sebagai MAC Address palsu anda.\r\n\r\nAda catatan dari saya sedikit buat Anda. Sebelum anda meng-install software tersebut. Pertama-tama anda harus download .NET Framework 2.0 sebagai pendukungnya.\r\n\r\nAnda tertarik dengan software ini silahkan download di http://www.hide-my-ip.com. untuk software pendukungnya Anda bisa download di http://www.microsoft.com.\r\nSelamat mencoba!\r\n\r\n', '2017-06-06', '0'),
(2, 3, 'Bagian umu diklat', 'Menyembunyikan MAC Address Pada pertemuan kali ini saya akan menjelaskan aplikasi sederhana yang saya dapatkan untuk menyembunyikan MAC Address kita dari gangguan user nakal yang terdapat dijaringan. Untuk menyembunyikan MAC Address saya menggunakan program Hide My MAC Address 2.1.3380.16020 yang saya download 2 hari lalu di http://www.hide-my-ip.com aplikasi ini sangat sederhana gampang untuk digunakan oleh pemula. untuk mengetahui langkah dasarnya silahkan ikuti petunjuk dibawah ini. Ada dua cara kita untuk menyembunyikan MAC Address kita, yaitu Cara pertama, sama sekali tidak menampilkan MAC Address kepada siapapun dijaringan. Cara kedua adalah cara untuk para user Advanced, dengan cara ini kita bisa memasukan MAC Address sesuka kita atau random MAC Address, sehingga MAC Address yang terdapat dijaringan bukanlah MAC Adddress yang asli. Bila anda menginginkan cara Advanced untuk menyembunyikan MAC Address anda, maka ikutilah langkah-langkah berikut : â€¢ Jalankan program Hide My MAC Address dan centang check box Advanced User Mode â€¢ Maka jendela program tersebut akan memanjang kebawah dan tampilan akan lebih lengkap lagi â€¢ Pada spoof MAC Address ada 6 kotak isian yang bisa anda isi untuk menampilkan MAC Address palsu dijaringan bila MAC Address sudah diisi lalu tekan spoof dan koneksipun direstart secara otomatis. Disini MAC Address yang anda masukan merupakan MAC Address palsu untuk mengecoh jaringan. â€¢ Bila anda susah dalam menentukan MAC Address, program ini juga mempunyai fasilitas untuk menentukan MAC Address secara otomatis. Cukup gampang anda Cuma klik tombol Random dan tekan spoof untuk menetapkannya sebagai MAC Address palsu anda. Ada catatan dari saya sedikit buat Anda. Sebelum anda meng-install software tersebut. Pertama-tama anda harus download .NET Fra', '2017-06-06', '0'),
(3, 3, 'Pelayanan Medical Reccord', 'Menyembunyikan MAC Address\r\nPada pertemuan kali ini saya akan menjelaskan aplikasi sederhana yang saya dapatkan untuk menyembunyikan MAC Address kita dari gangguan user nakal yang terdapat dijaringan.\r\n\r\nUntuk menyembunyikan MAC Address saya menggunakan program Hide My MAC Address 2.1.3380.16020 yang saya download 2 hari lalu di http://www.hide-my-ip.com aplikasi ini sangat sederhana gampang untuk digunakan oleh pemula. untuk mengetahui langkah dasarnya silahkan ikuti petunjuk dibawah ini.\r\n\r\nAda dua cara kita untuk menyembunyikan MAC Address kita, yaitu\r\nCara pertama, sama sekali tidak menampilkan MAC Address kepada siapapun dijaringan.\r\nCara kedua adalah cara untuk para user Advanced, dengan cara ini kita bisa memasukan MAC Address sesuka kita atau random MAC Address, sehingga MAC Address yang terdapat dijaringan bukanlah MAC Adddress yang asli.\r\n\r\nBila anda menginginkan cara Advanced untuk menyembunyikan MAC Address anda, maka ikutilah langkah-langkah berikut :\r\nâ€¢  Jalankan program Hide My MAC Address dan centang check box Advanced User Mode\r\nâ€¢  Maka jendela program tersebut akan memanjang kebawah dan tampilan akan lebih lengkap lagi\r\nâ€¢  Pada spoof MAC Address ada 6 kotak isian yang bisa anda isi untuk menampilkan MAC Address palsu dijaringan bila MAC Address sudah diisi lalu tekan spoof dan koneksipun direstart secara otomatis. Disini MAC Address yang anda masukan merupakan MAC Address palsu untuk mengecoh jaringan.\r\nâ€¢  Bila anda susah dalam menentukan MAC Address, program ini juga mempunyai fasilitas untuk menentukan MAC Address secara otomatis. Cukup gampang anda Cuma klik tombol Random dan tekan spoof untuk menetapkannya sebagai MAC Address palsu anda.\r\n\r\nAda catatan dari saya sedikit buat Anda. Sebelum anda meng-install software tersebut. Pertama-tama anda harus download .NET Framework 2.0 sebagai pendukungnya.\r\n\r\nAnda tertarik dengan software ini silahkan download di http://www.hide-my-ip.com. untuk software pendukungnya Anda bisa download di http://www.microsoft.com.\r\nSelamat mencoba!\r\n\r\n', '2017-06-06', 'hati.png'),
(4, 1, 'Bangsal interna', 'adalah tempat dimana terdapat', '2017-06-15', ''),
(5, 1, 'ICU', 'temapatfgdm icu ad', '2017-06-15', ''),
(6, 2, 'Klinik Anak', '									< ahref="#">Baca Selengkapnya</a>\r\n', '2017-06-15', ''),
(7, 2, 'Klinik Mata', '											<a href="#">Baca Selengkapnya</a>\r\n', '2017-06-15', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
`id` int(11) NOT NULL,
  `user` varchar(120) NOT NULL,
  `pass` varchar(120) NOT NULL,
  `type` varchar(120) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `user`, `pass`, `type`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_download`
--

CREATE TABLE IF NOT EXISTS `tbl_download` (
`id` int(11) NOT NULL,
  `judul` text NOT NULL,
  `foto` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_download`
--

INSERT INTO `tbl_download` (`id`, `judul`, `foto`) VALUES
(1, 'kfdkfldk', 'df3e1130595f7f0fcc700c113e3b2448.doc'),
(2, 'DFDF', 'ada.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE IF NOT EXISTS `tbl_kategori` (
`id` int(11) NOT NULL,
  `nama_kat` varchar(50) NOT NULL,
  `ket_kat` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`id`, `nama_kat`, `ket_kat`) VALUES
(1, 'Remunerasi', ''),
(2, 'Kegiatan', ''),
(3, 'Pelayanan', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_katpel`
--

CREATE TABLE IF NOT EXISTS `tbl_katpel` (
`id` int(11) NOT NULL,
  `nama_pel` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_katpel`
--

INSERT INTO `tbl_katpel` (`id`, `nama_pel`) VALUES
(1, 'Rawat Inap'),
(2, 'Rawat Jalan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_profile`
--

CREATE TABLE IF NOT EXISTS `tbl_profile` (
`id` int(11) NOT NULL,
  `judul` text NOT NULL,
  `isi_profile` text NOT NULL,
  `kategori` int(11) NOT NULL,
  `foto` varchar(123) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_profile`
--

INSERT INTO `tbl_profile` (`id`, `judul`, `isi_profile`, `kategori`, `foto`) VALUES
(1, ' dasdasds', ' ', 2, 'images (1).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sejarah`
--

CREATE TABLE IF NOT EXISTS `tbl_sejarah` (
`id` int(11) NOT NULL,
  `judul` varchar(500) NOT NULL,
  `isi_sejarah` text NOT NULL,
  `foto` varchar(230) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sejarah`
--

INSERT INTO `tbl_sejarah` (`id`, `judul`, `isi_sejarah`, `foto`) VALUES
(2, 'sdsa', 'sds', 'download.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slide`
--

CREATE TABLE IF NOT EXISTS `tbl_slide` (
`id` int(11) NOT NULL,
  `foto` varchar(300) NOT NULL,
  `ket` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_slide`
--

INSERT INTO `tbl_slide` (`id`, `foto`, `ket`) VALUES
(2, 'download.jpg', 'aan sakti'),
(3, '240_F_65704515_Y3XjEOCYefGNXKURFAQpFeZ9o8QGVpEt.jpg', 'selamat datang di web kami');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_spesialis`
--

CREATE TABLE IF NOT EXISTS `tbl_spesialis` (
`id_spes` int(11) NOT NULL,
  `nama_spes` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_spesialis`
--

INSERT INTO `tbl_spesialis` (`id_spes`, `nama_spes`) VALUES
(1, 'Dokter Spesialis Bedah'),
(2, 'Dokter Spesialis Syaraf'),
(3, 'Dokter Spesialis Orthopedi'),
(4, 'Dokter Spesialis Mata'),
(5, 'Dokter Spesialis Jantung'),
(6, 'Dokter Spesialis Anak'),
(7, 'Dokter Spesialis Dalam'),
(8, 'Dokter Umum');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_statistik`
--

CREATE TABLE IF NOT EXISTS `tbl_statistik` (
`id` int(11) NOT NULL,
  `status_bekerja` varchar(120) NOT NULL,
  `status_penempatan` varchar(120) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_statistik`
--

INSERT INTO `tbl_statistik` (`id`, `status_bekerja`, `status_penempatan`, `jumlah`) VALUES
(3, 'PNS', 'Dokter PNS', 13),
(4, 'PNS', 'Penunjang Medik PNS', 10),
(5, 'PNS', 'Bidan PNS', 10),
(6, 'PNS', 'Perawat PNS', 30),
(7, 'PNS', 'Penunjang Non Medik PNS', 23),
(8, 'PNS', 'Tenaga lainnya PNS', 60),
(9, 'SUKARELA', 'Dokter PTT', 2),
(10, 'SUKARELA', 'Perawat PTT', 200),
(11, 'SUKARELA', 'Bidan PTT', 60),
(12, 'SUKARELA', 'Penunjang Medik PTT', 30),
(13, 'SUKARELA', 'Penunjang Non Medik PTT', 120),
(14, 'SUKARELA', 'Tenaga lainnya PTT', 40);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_struktural`
--

CREATE TABLE IF NOT EXISTS `tbl_struktural` (
`id` int(11) NOT NULL,
  `judul` varchar(500) NOT NULL,
  `isi_struktural` text NOT NULL,
  `foto` varchar(230) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_struktural`
--

INSERT INTO `tbl_struktural` (`id`, `judul`, `isi_struktural`, `foto`) VALUES
(1, 'SAD', 'SDS', 'images.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_visi`
--

CREATE TABLE IF NOT EXISTS `tbl_visi` (
`id` int(11) NOT NULL,
  `judul` varchar(500) NOT NULL,
  `isi_visi` text NOT NULL,
  `foto` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_visi`
--

INSERT INTO `tbl_visi` (`id`, `judul`, `isi_visi`, `foto`) VALUES
(2, 'fdsfsd', 'dfsd', 'images.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galeri`
--
ALTER TABLE `galeri`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pelayanan`
--
ALTER TABLE `pelayanan`
 ADD PRIMARY KEY (`id_pelayanan`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_download`
--
ALTER TABLE `tbl_download`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_katpel`
--
ALTER TABLE `tbl_katpel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_profile`
--
ALTER TABLE `tbl_profile`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sejarah`
--
ALTER TABLE `tbl_sejarah`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slide`
--
ALTER TABLE `tbl_slide`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_spesialis`
--
ALTER TABLE `tbl_spesialis`
 ADD PRIMARY KEY (`id_spes`);

--
-- Indexes for table `tbl_statistik`
--
ALTER TABLE `tbl_statistik`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_struktural`
--
ALTER TABLE `tbl_struktural`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_visi`
--
ALTER TABLE `tbl_visi`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `galeri`
--
ALTER TABLE `galeri`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pelayanan`
--
ALTER TABLE `pelayanan`
MODIFY `id_pelayanan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_download`
--
ALTER TABLE `tbl_download`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_katpel`
--
ALTER TABLE `tbl_katpel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_profile`
--
ALTER TABLE `tbl_profile`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_sejarah`
--
ALTER TABLE `tbl_sejarah`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_slide`
--
ALTER TABLE `tbl_slide`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_spesialis`
--
ALTER TABLE `tbl_spesialis`
MODIFY `id_spes` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_statistik`
--
ALTER TABLE `tbl_statistik`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tbl_struktural`
--
ALTER TABLE `tbl_struktural`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_visi`
--
ALTER TABLE `tbl_visi`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
