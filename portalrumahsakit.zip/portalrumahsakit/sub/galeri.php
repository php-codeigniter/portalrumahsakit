					<p></p>
					
					<section id="portfolio">
    <div class="container">
	<div class="row">
				<div class="title text-center col-sm-12">
					<h2><i class="fa fa-newspaper-o fa-fw"></i> Photo Gallery</h2>
				</div>
			</div>
      
        <div class="row"> 
		<div class="panel-body">
				<div class="portfolio-gallery">
				
				  <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM berita ORDER BY id DESC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "
			<div class='col-sm-4'>
			<div class='portfolio-gallery-item'>
				<img class='img-thumbnail' src='foto/".$data['foto']. "' alt='Image1'>
					<a href='foto/galeri/".$data['foto']. "' rel='prettyPhoto[gallery]'>
								<i class='fa fa-search-plus'></i>
							</a>
					
		                </div>
		                </div>
		                
						
		               
	                ";

			}
		?>
					
						
							
							
						</div>
					</div>
					
				</div>
				</div>
			
		
	</section>

	
	