 <?php
include "module/koneksi.php";
?><!-- Header End -->
	
	<!-- Portfolio Start -->
	<section id="portfolio">
		<div class="container">
		



			<div class="row">
				<div class="title text-center col-sm-12">
					<h2><i class="fa fa-book fa-fw"></i> DOWNLOAD</h2>
				</div>
	</div>
	</section>
	
	
	<section id="portfolio">
 
 <div class="container content">
			<div class="row">
				<div class="col-sm-8">
					<div class="panel panel-default">
		
						<div class="panel-heading"><i class="fa fa-book fa-fw"></i> DOWNLOAD</div>
						<div class="panel-body">
							<div id="berita">
																	<div class="berita single">
										 <table class="table table-bordered" style="background: #f3f3f3;">
    <thead>
      <tr>
        <th>NO</th>
        <th>JUDUL</th>
        <th>DOWNLOAD FILE</th>
      </tr>
    </thead>
				 <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM tbl_download ORDER BY id DESC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "	 <tbody>
		                	<tr>
       
        <td>".$pageNum."</td>
        <td><a href='#".$data['judul']."'>".$data['judul']."</a></td>
        <td><a href='foto/download/".$data['foto']."'>DOWNLOAD</a></td>
		</td>
      </tr>
		</tbody>
		               
	                ";

			}
		?>
					
			</table>
										
										
										
									</div>
															</div>
						</div>
						<div class="panel-footer shares">

						</div>
					</div>
				</div> <!-- Col sm 8 -->


				<div class="col-sm-4">
<?php include "sub/sidebardirektur.php" ?>

</div>
</div>
</section>					

	
	
	

					


					
					
