<?php
include "module/koneksi.php";
?>   
         
        

			<section id="pelayanan">
    <div class="container">
	<div class="row">
				<div class="title text-center col-sm-12">
				<h2><i class="fa fa-info-circle"></i>INFO PELAYANAN </h2>
				</div>
			</div>
      
        <div class="row"> 
		<div class="panel-body">
	
				<div class="col-sm-8">
					<div class="panel panel-default">
					   <?php
			$id_pelayanan = $_GET['id_pelayanan'];
			$query = "SELECT * FROM pelayanan where id_pelayanan='$id_pelayanan'";
			$result = mysql_query($query);
			$data = mysql_fetch_array($result);
		?>  
						<div class="panel-heading"><i class="fa fa-newspaper-o fa-fw"></i> DETAIL PELAYANAN</div>
						<div class="panel-body">
							<div id="berita">
																	<div class="berita single">
										<h2 style="font-size:18px;"> <i class="fa fa-newspaper-o fa-fw"></i> <?php echo $data['judul'];?> </h2>
										<div class="berita-single-gambar">
<img src="foto/<?php echo $data['foto']; ?>" width="100%"/>										</div>
										<div class="meta">
											<h2 style="font-size:12px;"><i class="fa fa-user fa-fw"></i> Administrator 
											<i class="fa fa-clock-o fa-fw"></i> <?php echo $data['tanggal']; ?> </h2>
											
										</div>
										<small class="text-muted"><em><strong></strong></em></small>
										<p></p>
										<div class="post-content"><p style="text-align: justify;"><?php echo $data['isi_berita']; ?></p>
<p>&nbsp;</p></div>
									</div>
															</div>
						</div>
						<div class="panel-footer shares">

						</div>
					</div>
				</div> <!-- Col sm 8 -->


				<div class="col-sm-4">
<?php 
include "sub/sidebarberita.php"; 
?>

</div>
</div>
</div>
</div>
</section>



	
	
	
	
