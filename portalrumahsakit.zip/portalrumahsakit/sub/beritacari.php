 <?php
include "module/koneksi.php";
?>

<section id="berita">
		<div class="container">
		<div class="row">
<?php	if(!empty($_GET['id'])){ ?>
		<?php
			extract($_GET); 
			$k = mysql_query("SELECT * FROM berita where id='$id'"); 
			$data = mysql_fetch_array($k);
		?>
		
		
<?php }elseif(!empty($_GET['kategori'])){ ?>	

		<?php
			extract($_GET); 
			$kat = mysql_fetch_array(mysql_query("SELECT * FROM tbl_kategori where id='$kategori'")); 
		?>
		
		<div class="title text-left col-sm-12">
					<h2><i class="fa fa-book fa-fw"></i>Kategori : <?php echo $kat['nama_kat'] ?> </h2>
				</div>
				<?php 
					$k = mysql_query("SELECT * FROM berita where kategori='$kategori'");
					while($data = mysql_fetch_array($k)){
				?>
				<div class="col-md-4 content-menu">
					<a href="home.php?menu=detailberita&id=<?php echo $data['id'] ?>">
						<img class="img-thumbnail" src="foto/<?php echo $data['foto'] ?>" width="100%">
						<h4><?php echo $data['judul'] ?></h4>
					</a>
					<p style="font-size:18px"><?php echo substr($data['isi_berita'],0,70) ?>.....</p>
					<p>
						<a href="home.php?menu=detailberita&id=<?php echo $data['id'] ?>" class="btn btn-primary btn-sm" href="#" role="button">Baca Selengkapnya</a>
					</p>
				</div>  
				<?php } ?>
				

<?php }else{ ?>	
		
		
		

<?php } ?>	
</div>
		</div>
		</section>