
<?php
include "module/koneksi.php";
include "module/modul_lokasi.php";

?>
 
  <!-- <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script> -->
 
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBzxq53hccrqVLdZ0r4W8YQ-YxD2Fm7l_8&callback=initMap"
  type="text/javascript"></script>
<section>
      
	<div class="container">
  <div id="map" style="width:600px;height: 300px;"></div>
   <form   method="POST" id="form1" action="module/modul_lokasi.php?action=add" class='form-horizontal'>
    <br/>
    <div class="control-group">
       <label class="control-label" for="nama">Nama Lokasi</label>
       <div class="controls">
         <input type="text" name='nama' class='input-xlarge'>
       </div>
     </div> 
     <div class="control-group">
       <label class="control-label" for="lat">latitude</label>
       <div class="controls">
         <input type="text" name="lat" id="lat"  >
       </div>
     </div>
     <div class="control-group">
       <label class="control-label" for="ing">Longitude</label>
       <div class="controls">
         <input type="text" name="ing" id="ing" >
       </div>
     </div>
     <div class="control-group">
       <div class="controls">
         <button type="submit" class="btn btn-success" name='action'>Submit</button>
       </div>
     </div>
    </form>
	

<script type="text/javascript">
    document.getElementById('reset').onclick= function() {
        var field1= document.getElementById('ing');
 var field2= document.getElementById('lat');
        field1.value= field1.defaultValue;
 field2.value= field2.defaultValue;
    };
</script>    
<script type="text/javascript">
     function updateMarkerPosition(latLng) {
  document.getElementById('lat').value = [latLng.lat()];
  document.getElementById('ing').value = [latLng.lng()];
  }

    var myOptions = {
      zoom: 7,
        scaleControl: true,
      center:  new google.maps.LatLng(-2.937052,120.179216),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };

 
    var map = new google.maps.Map(document.getElementById("map"),
        myOptions);

 var marker1 = new google.maps.Marker({
 position : new google.maps.LatLng(-2.937052,120.179216),
 title : 'lokasi',
 map : map,
 draggable : true

 });
 
 //updateMarkerPosition(latLng);

 google.maps.event.addListener(marker1, 'drag', function() {
  updateMarkerPosition(marker1.getPosition());
 });
</script>
</div>
</section>
	<section id="statistik">
<div class="statistik">
    <div class="container">
	<div class="row">
				
			</div>
      
        <div class="row"> 
		<div class="panel-body">
				<div id="container">
				
				</div>
			</div>
			
		</div>
		</div>
	</section>

