 <?php
include "module/koneksi.php";
?>
	<section id="about">
<div class="about">
    <div class="container">
	<div class="row">
				<div class="title text-center col-sm-12">
					<h2>PROFILE</h2>
				</div>
			</div>
      
        <div class="row"> 
		<div class="panel-body">
			<div class="col-sm-6">
			
			 <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM tbl_profile ORDER BY id DESC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
			{
			echo "		
							<h2>".$data['judul']."</h2>
							<div class='about-team-person-image'>
								<img class='img-thumbnail' src='foto/adm/".$data['foto']. "' alt='Team1' style='border-radius: 3px;' align='center' width='150' height='150'>
							</div>
						<div class='about-company'>
						<p>	".$data['isi_profile']."</p>
							
						 </div>

		               
	                ";

			}
		?>
			 </div>
				
				<?php include ("sub/direktur.php"); ?>
			</div>
			</div>
			</div>
			
		</div>
	</section>
	
	
	




					
	
	<section id="about">
<div class="about">
    <div class="container">
	<div class="row">
				<div class="title text-center col-sm-12">
					<h2>ARTIKEL</h2>
				</div>
			</div><div class="row">
      	<div class="about-team" style="box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2)">
 
		<div class="panel-body">
	
				 <?php
		// jumlah data perhalaman
		$rowsPerPage = 4;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM berita ORDER BY id ASC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "	

			<div class='col-sm-6 col-md-3'>
						<div class='about-team-person text-center'>
		
							<div class='about-team-person-image'>
								<img class='img-responsive' src='foto/".$data['foto']. "' alt='Team1'>
							</div>
							<div class='about-team-person-info'>
							<h3>".$data['judul']."</h3>
					<h4> Administrator - ".$data['tanggal']."
					</h4>
						<p>	".substr($data['isi_berita'],0,200)."....</p>
											<a button type='button' class='btn btn-primary btn-md' href='home.php?menu=detailberita&id=".$data['id']."'>Baca Selengkapnya</a></p>

												<div class='about-team-person-social-icons'>
								<ul>
									<li><a class='facebook' href='#'><i class='fa fa-facebook'></i></a></li>
									<li><a class='twitter' href='#'><i class='fa fa-twitter'></i></a></li>
									<li><a class='linkedin' href='#'><i class='fa fa-linkedin'></i></a></li>
									<li><a class='dribbble' href='#'><i class='fa fa-dribbble'></i></a></li>
									<li><a class='rss' href='#'><i class='fa fa-rss'></i></a></li>
								</ul>
							</div>
						</div>
		                </div>
		                </div>
		                
						 
		               
	                ";

			}
		?>
					
						
			              
		               
		                
		                </div>
		                </div>
		                </div>
		                </div>
		                </section>
						
					
					
					
					