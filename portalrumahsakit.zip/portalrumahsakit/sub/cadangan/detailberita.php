<?php
include "module/koneksi.php";
?>   
         
        
	<section id="portfolio">
		<div class="container">
			<div class="row">
				<div class="title text-center col-sm-12">
					<h2><i class="fa fa-book fa-fw"></i>Berita Terbaru </h2>
				</div>
			</div>
			
		</div>
	</section>


 <section id="portfolio">
 
 <div class="container content">
			<div class="row">
				<div class="col-sm-8">
					<div class="panel panel-default">
					   <?php
			$id = $_GET['id'];
			$query = "SELECT * FROM berita where id = '$id'";
			$result = mysql_query($query);
			$data = mysql_fetch_array($result);
		?>  
						<div class="panel-heading"><i class="fa fa-newspaper-o fa-fw"></i> BERITA</div>
						<div class="panel-body">
							<div id="berita">
																	<div class="berita single">
										<h5><a href="#"><?php echo $data['judul'];?></a></h5>
										<div class="berita-single-gambar">
<img src="foto/<?php echo $data['foto']; ?>" width="100%"/>										</div>
										<div class="meta">
											<span class=""><i class="fa fa-user fa-fw"></i> Administrator </span>
											<span class=""><i class="fa fa-clock-o fa-fw"></i> <?php echo $data['tanggal']; ?> </span>
											<span class=""><i class="fa fa-eye fa-fw"></i> 141 </span>
										</div>
										<small class="text-muted"><em><strong></strong></em></small>
										<p></p>
										<div class="post-content"><p style="text-align: justify;"><?php echo $data['isi_berita']; ?></p>
<p>&nbsp;</p></div>
									</div>
															</div>
						</div>
						<div class="panel-footer shares">

						</div>
					</div>
				</div> <!-- Col sm 8 -->


				<div class="col-sm-4">

					<div class="panel panel-default pemimpin">
	<div class="panel-heading"><i class="fa fa-newspaper-o fa-fw"></i> BERITA</div>
  	<div class="about-skills">
						<ul class="nav nav-tabs">
  <li class="active" align="center"><a data-toggle="tab" href="#home">TERBARU</a></li>
  <li><a data-toggle="tab" href="#menu1">ACAK</a></li>
  <li><a data-toggle="tab" href="#menu2">LAMA</a></li>
</ul>

<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
   <ul class="highest">
							<h3></h3>																				
			
  </div>
  <div id="menu1" class="tab-pane fade">
    <h3>DIREKTUR ADMINISTRASI</h3>
								<img class='img-thumbnail' src='http://localhost/portalrumahsakit/images/dr1.png' alt='Team1' style='border-radius: 3px;' align='center' style='width:100%;'>
  <h3></h3>
  </div>
  <div id="menu2" class="tab-pane fade">
    <h3>DREKTUR PELAYANAN</h3>
    <p>
								<img class='img-thumbnail' src='http://localhost/portalrumahsakit/images/d1.jpg' alt='Team1' style='border-radius: 3px;' align='center' style='width:100%;'>
							</p>
							<h3></h3>
  </div>
</div>
					</div>
</div>
</div>
</div>
</section>

	
	
	
	
	
	  <!-- About Us Text -->
        <div class="about-us-container">
        	<div class="container">
	            <div class="row">
				<div class="panel panel-default">
				    <?php
			$id = $_GET['id'];
			$query = "SELECT * FROM berita where id = '$id'";
			$result = mysql_query($query);
			$data = mysql_fetch_array($result);
		?>  
	                 <div class="panel-heading">
	                    <h3 style="font-family: 'MTKIFONT';"><?php echo $data['judul'];?></h3></div>
	                    <h3><span class=''><i class='fa fa-user fa-fw'></i>Administrator</span>, <span class=''><i class='fa fa-clock-o fa-fw'></i><?php echo $data['tanggal']; ?></span></h3>
	                   <div class="panel-body"> <p>
		
					<td><img src="foto/<?php echo $data['foto']; ?>"  width="350" height="350" style="float:left; border-radius:2px; margin: 5px 10px 10px 0px;" width="20%"/></td>
					<p style="font-style: normal;">
								<?php echo $data['isi_berita']; ?>
						</td>
						</div>
				</p>
		
	                </div>
	                </div>
	            </div>
	        </div>
        </div>
        </div>
 
	
