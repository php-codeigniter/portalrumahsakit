 <?php
include "module/koneksi.php";
?>


		<section id="berita">
<div class="berita">
    <div class="container">
	<div class="row">
				<div class="title text-center col-sm-12">
					<h2><i class="fa fa-globe"></i> BERITA </h2>
				</div>
			</div>
      
        <div class="row">

	<div class="panel-body">
				 <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM berita ORDER BY id DESC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "			<div class='col-sm-6 col-md-3'>
						<div class='about-team-person text-center'>
		
							<div class='about-team-person-image'>
								<img class='img-thumbnail' src='foto/".$data['foto']. "' alt='Team1' >
							</div>
							<div class='about-team-person-info'>
							<h3 align='left' class='text-success'>".$data['judul']."</h3>
					<h2 align='left' style='font-size:12px'><i class='fa fa-user fa-fw'></i> Administrator - <i class='fa fa-clock-o fa-fw'></i>".$data['tanggal']."
					</h2>
						<p align='left'>	".substr($data['isi_berita'],0,180)."....
											<a button type='button' class='btn btn-primary btn-md' href='home.php?menu=detailberita&id=".$data['id']."'>Baca Selengkapnya</a></p>

								
						</div>
		                </div>
		                </div>
						 
		               
	                ";

			}
		?>
					
						
			              
		               
		                </div>
		                </div>
		            
		               
		       
						
					
					

<div class="row">
<div class="panel-body">
    <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM berita ORDER BY id ASC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "
			<div class='col-sm-4'>
			<div class='portfolio-box-container'>
			
				<img class='img-thumbnail' src='foto/".$data['foto']. "' width='200' height='200'>
				<h3 class='text-success'>".$data['judul']."</h3>
					<h2 align='left' style='font-size:12px'><i class='fa fa-user fa-fw'></i> Administrator - <i class='fa fa-clock-o fa-fw'></i>".$data['tanggal']."
					</h3>
							".substr($data['isi_berita'],0,200)."....<p>
					<a button type='button' class='btn btn-primary btn-md' href='home.php?menu=detailberita&id=".$data['id']."'>Baca Selengkapnya</a>
			                </p>
		                </div>
		                </div>
		                
						
		               
	                ";

			}
		?>
		
    
   

    </div>

    </div>
			  <ul class="pagination">
  <li><a href="#">1</a></li>
  <li class="active"><a href="#">2</a></li>
  <li><a href="#">3</a></li>
  <li><a href="#">4</a></li>
  <li><a href="#">5</a></li>
</ul>
    </div>
    </div>
	</section>
				