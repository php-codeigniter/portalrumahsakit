
    <!-- Page Content -->
    <div class="container">

      <!-- Heading Row -->
      <div class="row my-4">
        <div class="col-lg-8">
          <img class="img-fluid rounded" src="http://placehold.it/900x400" alt="">
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-4">
                    <h1>KATA SAMBUTAN</h1>
          <p>This is a template that is great for small businesses. It doesn't have too much fancy flare to it, but it makes a great use of the standard Bootstrap core components. Feel free to use this template for any project you want!</p>
          <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">SELAMAT DATANG</h4>
      </div>
      <div class="modal-body">
        <p>Selamat datang di website desa </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
							
							
							
        </div>
        <!-- /.col-md-4 -->
      </div>
      <!-- /.row -->

      <!-- Call to Action Well -->
      <div class="card text-white bg-secondary my-4 text-center">
        <div class="card-body">
          <p class="text-white m-0"><marquee>This call to action card is a great place to showcase some important information or display a clever tagline!</marquee></p>
        </div>
      </div>




<div class="container" style="padding-top:30px">
    <h1 class="text-center">Outlined and Light Background Style</h1>
  <div class="row">
<div class="col-sm-6">
            <div id="tb-testimonial" class="testimonial testimonial-info-filled">
                <div class="testimonial-section">
                    Denim you probably haven't heard of. Lorem ipsum dolor met consectetur adipisicing sit amet, consectetur adipisicing elit, of them jean shorts sed magna aliqua. Lorem ipsum dolor met.
                </div>
                <div class="testimonial-desc">
                    <img src="https://placeholdit.imgix.net/~text?txtsize=9&txt=100%C3%97100&w=100&h=100" alt="" />
                    <div class="testimonial-writer">
                      <div class="testimonial-writer-name">Zahed Kamal</div>
                      <div class="testimonial-writer-designation">Front End Developer</div>
                      <a href="#" class="testimonial-writer-company">Touch Base Inc</a>
                    </div>
                </div>
            </div>   
    </div>
        
        <div class="col-sm-6">
            <div id="tb-testimonial" class="testimonial testimonial-success-filled">
                <div class="testimonial-section">
                    Denim you probably haven't heard of. Lorem ipsum dolor met consectetur adipisicing sit amet, consectetur adipisicing elit, of them jean shorts sed magna aliqua. Lorem ipsum dolor met.
                </div>
                <div class="testimonial-desc">
                    <img src="https://placeholdit.imgix.net/~text?txtsize=9&txt=100%C3%97100&w=100&h=100" alt="" />
                    <div class="testimonial-writer">
                      <div class="testimonial-writer-name">Zahed Kamal</div>
                      <div class="testimonial-writer-designation">Front End Developer</div>
                      <a href="#" class="testimonial-writer-company">Touch Base Inc</a>
                    </div>
                </div>
            </div>   
    </div>
        
       
    </div>
  </div>




  
  
  
  
  
  
<div class="container" style="padding-top:30px">


      <!-- Content Row -->
      <div class="row">
   
		
		
		
		
		
		
	
				 <?php
		// jumlah data perhalaman
		$rowsPerPage = 25;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM berita ORDER BY id DESC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "			
			
			
			    <div class='col-md-4 mb-4'>
          <div class='card h-100'>
            <div class='card-body'>
              <h2 class='card-title'>	<a href='home.php?menu=detailberita&id=".$data['id']."'><h3 align='left' class='text-success' style='font-weight: bold;'>".$data['judul']."</h3></a></h2>
			  <h4 align='left' style='font-size:12px;'><span class=''><i class='fa fa-user fa-fw'></i>administrator </span>-  <span class=''><i class='fa fa-clock-o fa-fw'></i>". date('d-m-Y', strtotime($data['tanggal']))."</span>
					</h4>
			  
			  
              <p class='card-text'>".substr($data['isi_berita'],0,100)."....</p>
            </div>
            <div class='card-footer'>
              <a class='btn btn-primary' href='home.php?menu=detailberita&id=".$data['id']." '>More Info</a>
            </div>
          </div>
        </div>
			
			
";

			}
		?>
			
		
		
		
		
		
		
		

        <!-- /.col-md-4 -->

      </div>
      <!-- /.row -->

    </div>
    </div>
    <!-- /.container -->


<section id="alamat">
  <div class="container">
    <div class="well well-sm">
      <h3><strong>Contact Us</strong></h3>
    </div>
  
  <div class="row">
    <div class="col-md-7">
        <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d3736489.7218514383!2d90.21589792292741!3d23.857125486636733!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sbd!4v1506502314230" width="100%" height="315" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>

      <div class="col-md-5">
          <h4><strong>Get in Touch</strong></h4>
        <form>
          <div class="form-group">
            <input type="text" class="form-control" name="" value="" placeholder="Name">
          </div>
          <div class="form-group">
            <input type="email" class="form-control" name="" value="" placeholder="E-mail">
          </div>
          <div class="form-group">
            <input type="tel" class="form-control" name="" value="" placeholder="Phone">
          </div>
          <div class="form-group">
            <textarea class="form-control" name="" rows="3" placeholder="Message"></textarea>
          </div>
          <button class="btn btn-default" type="submit" name="button">
              <i class="fa fa-paper-plane-o" aria-hidden="true"></i> Submit
          </button>
        </form>
      </div>
    </div>
  </div>
</section>
