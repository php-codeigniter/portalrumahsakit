
		<div class="col-sm-6">
		<div class="panel-body">
		 <h2><i class="fa fa-user fa-fw"></i>DIREKTUR KAMI</h2>
					<div class="about-skills">
						<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#home">DIREKTUR UTAMA</a></li>
  <li><a data-toggle="tab" href="#menu1">DIREKTUR ADMINISTRASI</a></li>
  <li><a data-toggle="tab" href="#menu2">DIREKTUR PELAYANAN</a></li>
</ul>

<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
    <h3>DREKTUR UTAMA</h3>
    <p>
								<img class='img-thumbnail' src='http://localhost/portalrumahsakit/images/d1.jpg' alt='Team1' style='border-radius: 3px;' align='center' style='width:100%;'>
							</p>
							<h3></h3>
  </div>
  <div id="menu1" class="tab-pane fade">
    <h3>DIREKTUR ADMINISTRASI</h3>
								<img class='img-thumbnail' src='http://localhost/portalrumahsakit/images/dr1.png' alt='Team1' style='border-radius: 3px;' align='center' style='width:100%;'>
  <h3></h3>
  </div>
  <div id="menu2" class="tab-pane fade">
    <h3>DREKTUR PELAYANAN</h3>
    <p>
								<img class='img-thumbnail' src='http://localhost/portalrumahsakit/images/d1.jpg' alt='Team1' style='border-radius: 3px;' align='center' style='width:100%;'>
							</p>
							<h3></h3>
  </div>
</div>
					</div>
				
	
		
			</div>
			</div>