 <?php
include "module/koneksi.php";
?><!-- Header End -->
	
	<!-- Portfolio Start -->
	<section id="portfolio">
		<div class="container">
		



			<div class="row">
				<div class="title text-center col-sm-12">
					<h2><i class="fa fa-info-circle"></i> INFO PELAYANAN </h2>
				</div>
	</div>
	</section>

	<section id="portfolio">
 
 <div class="container content">
			<div class="row">
			
	
				<div class="col-sm-8">
					<div class="panel panel-default">
				<?php	if(!empty($_GET['id'])){ ?>
		<?php
			extract($_GET); 
			$k = mysql_query("SELECT * FROM pelayanan where id_pelayanan='$id_pelayanan'"); 
			$data = mysql_fetch_array($k);
		?>
		
		
<?php }elseif(!empty($_GET['kategori'])){ ?>	

		<?php
			extract($_GET); 
			$kat = mysql_fetch_array(mysql_query("SELECT * FROM tbl_katpel where id='$kategori'")); 
		?>
						<div class="panel-heading"><i class="fa fa-info-circle"></i> PELAYANAN : <?php echo $kat['nama_pel'] ?></div>
						<div class="panel-body">
							<div id="berita">
							
																	<div class="berita single">
										 <table class="table table-bordered" style="background: #f3f3f3;">
    <thead>
      <tr>
        <th>NO</th>
        <th>RUANGAN</th>
        <th>ISI</th>
        <th>DETAIL</th>
      </tr>
    </thead>
				 <tbody>
				 <?php 
					$k = mysql_query("SELECT * FROM pelayanan where kategori='$kategori'");
					$no=$data+1;
					while($data = mysql_fetch_array($k))
					{
				?>
		                	<tr>
       
        <td><?php echo $no ?></td>
        <td><?php echo $data['judul'] ?></td>
        <td><img class="img-thumbnail" src="foto/pelayanan/<?php echo $data['foto'] ?>" width="50" height="50"></td>
		<td><a href="home.php?menu=detailpelayanan&id_pelayanan=<?php echo $data['id_pelayanan'] ?>" class="btn btn-success btn-sm" href="#" role="button">Lihat Detail</a></td>
		</td>
      </tr> <?php
	 		$no++;
	 	}
	 ?>
								  			
				

<?php }else{ ?>	
		
		
		

<?php } ?>	
		</tbody>
		               
	             		
			</table>
										
		
										
									</div>
															</div>
						</div>
						<div class="panel-footer shares">

						</div>
					</div>
				</div> <!-- Col sm 8 -->


				<div class="col-sm-4">
<?php include "sub/sidebardirektur.php" ?>

</div>
</div>
</section>					
				


								
	
					


					
					
