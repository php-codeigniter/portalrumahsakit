 <?php
include "module/koneksi.php";
?>
<script src="assets/js/jquery.min.js" type="text/javascript"></script>
<script src="assets/js/highcharts.js" type="text/javascript"></script>
<script type="text/javascript">
	var chart1; // globally available
$(document).ready(function() {
      chart1 = new Highcharts.Chart({
         chart: {
            renderTo: 'container',
            type: 'column'
         },   
         title: {
            text: 'Grafik Tenaga Rumah Sakit '
         },
         xAxis: {
            categories: ['Penempatan']
         },
         yAxis: {
            title: {
               text: 'Jumlah Tenaga'
            }
         },
              series:             
            [
            <?php 
            $sql   = "SELECT status_penempatan  FROM tbl_statistik";
            $query = mysql_query( $sql )  or die(mysql_error());
            while( $ret = mysql_fetch_array( $query ) ){
            	$status_penempatan=$ret['status_penempatan'];                     
                 $sql_jumlah   = "SELECT jumlah FROM tbl_statistik WHERE status_penempatan='$status_penempatan'";        
                 $query_jumlah = mysql_query( $sql_jumlah ) or die(mysql_error());
                 while( $data = mysql_fetch_array( $query_jumlah ) ){
                    $jumlah = $data['jumlah'];                 
                  }             
                  ?>
                  {
                      name: '<?php echo $status_penempatan; ?>',
                      data: [<?php echo $jumlah; ?>]
                  },
                  <?php } ?>
            ]
      });
   });	
</script>
      
	
	<section id="statistik">
<div class="statistik">
    <div class="container">
	<div class="row">
				<div class="title text-center col-sm-12">
					<h2><i class="fa fa-bar-chart-o"></i> STATISTIK TENAGA RUMAH SAKIT</h2>
				</div>
			</div>
      
        <div class="row"> 
		<div class="panel-body">
				<div id="container">
				
				</div>
			</div>
			
		</div>
		</div>
	</section>

