					<div class="panel panel-default pemimpin">
	<div class="panel-heading"><i class="fa fa-globe"></i>  BERITA</div>
  	<div class="about-skills">
						<ul class="nav nav-tabs">
  <li class="active"><a data-toggle="tab" href="#home">TERBARU</a></li>
  <li><a data-toggle="tab" href="#menu1">ACAK</a></li>
  <li><a data-toggle="tab" href="#menu2">LAMA</a></li>
</ul>

<div class="tab-content">
  <div id="home" class="tab-pane fade in active">
  
	<table>
  
							<?php
		// jumlah data perhalaman
		$rowsPerPage = 7;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM berita ORDER BY id DESC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "		<tbody>
			<td>
		                	<tr align='left'>
		<td><img class='img-thumbnail' src='foto/".$data['foto']. "' alt='Team1' width='150' height='150'></td>&nbsp;&nbsp;&nbsp;
        <td> <a href='home.php?menu=detailberita&id=".$data['id']."'>".$data['judul']."</a></td>
		</td>
      </tr>
		</tbody>
		               
	                ";

			}
		?>
					</table>		
							
							
																										
			
  </div>
  <div id="menu1" class="tab-pane fade">
   <table>
							<?php
		
		$query = "SELECT * FROM berita ORDER BY RAND() LIMIT 7";
		$result = mysql_query($query);
		if ($result === FALSE) {
    die(mysql_error());
}
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "		<tbody>
			<td>
		                	<tr align='left'>
		<td><img class='img-thumbnail' src='foto/".$data['foto']. "' alt='Team1' width='150' height='150'></td>&nbsp;&nbsp;&nbsp;
        <td> <a href='home.php?menu=detailberita&id=".$data['id']."'>".$data['judul']."</a></td>
		</td>
      </tr>
		</tbody>
		               
	                ";

			}
		?>
					</table>	
  
							
  </div>
  <div id="menu2" class="tab-pane fade">
    <table>
  
							<?php
		// jumlah data perhalaman
		$rowsPerPage = 7;
		//nilai pertama
		$pageNum = 1;
		if(!empty($_GET['halaman']))
			{ 
				$pageNum = $_GET['halaman'];
			}
			$offset = ($pageNum - 1) * $rowsPerPage;
		$query = "SELECT * FROM berita ORDER BY id ASC LIMIT $offset, $rowsPerPage";
		$result = mysql_query($query);
		while ($data = mysql_fetch_array($result))
		
		
			{
			echo "		<tbody>
			<td>
		                	<tr align='left'>
		<td><img class='img-thumbnail' src='foto/".$data['foto']. "' alt='Team1' width='150' height='150'></td>&nbsp;&nbsp;&nbsp;
        <td> <a href='home.php?menu=detailberita&id=".$data['id']."'>".$data['judul']."</a></td>
		</td>
      </tr>
		</tbody>
		               
	                ";

			}
		?>
					</table>		
							
							
  </div>
</div>
					</div>
</div>