 <?php
include "module/koneksi.php";
?>

<link href="css.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type="text/javascript" src="jquery.validate.js"></script>
<script type="text/javascript">
        $(document).ready(function() {
            $("#form").validate({
                rules: {
                  txtsearch: "required",
                  kategori: "required"
                },
             
        messages: { 
                 txtsearch: {
                    required: ''
                },
                  kategori: {
                    required: ''
                },
        },
                success: function(label) {
            label.text('').addClass('valid');
         }
            });
        });
    </script>
		


	
	
	
	
	
	<section id="dokter">
<div class="dokter">
    <div class="container">
	<div class="row">
				<div class="title text-center col-sm-12">
					<h2><i class="fa fa-stethoscope"></i>  CARI JADWAL DOKTER</h2> 
				</div>
			</div>
      
        <div class="row"> 
				
				<div class="col-sm-8">
					<div class="panel panel-default">
						<div class="panel-heading"><i class="fa fa-stethoscope"></i>  DOKTER</div>
						<div class="panel-body">
							<div id="berita">
																	<div class="berita single">
																	
													 <h2>Dokter Kami</h2>
					                
				<form method="POST" action=""> 
				<div class="form-group">				
					<select for="txtsearch" name="txtsearch" id="id_spes" class="form-control" required>
						<option value="">- Cari Dokter Spesialis -</option>
							<?php
								$sel_spes = "SELECT id_spes, nama_spes FROM tbl_spesialis ORDER BY nama_spes";
								$q=mysql_query($sel_spes);
								while($data_spes=mysql_fetch_array($q)){
									echo'<option value="'.$data_spes["id_spes"].'">'.$data_spes["nama_spes"].'</option>';
									}
							?>
							</select>  
					<input type="submit" value="TAMPILKAN" name="submit"/>  
					</div>
										
   <table class="table table-bordered" style="background: #f3f3f3;">
    <thead>
      <tr>
        <th>NO</th>
        <th>NAMA DOKTER</th>
        <th>JAM KERJA</th>
        <th>DOKTER</th>
        <th>FOTO</th>
      </tr>
    </thead>
   
<?php  
  if (isset($_POST['submit'])) {
   $search = $_POST['txtsearch'];   
      
   $sql = "SELECT * FROM dokter JOIN tbl_spesialis On tbl_spesialis.id_spes=dokter.id_spes WHERE tbl_spesialis.id_spes LIKE '%$search%'";
   $i=1;
   $result = mysql_query($sql) or die("Error, list mata_pelajaran failed. " . mysql_error());  
       
   if (mysql_num_rows($result) == 0) {  
    echo "<p></p><p>Pencarian tidak ditemukan</p>";  
   } else {  
    echo "<p></p>";  
    while ($row = mysql_fetch_array($result)) { 
	extract($row); 
if (empty($row['foto'])) {
			$foto = "gravatar.jpg";
		}
		else{
			$foto = $row['foto'];
			}	 
     echo " <tbody>
		                	<tr>
       
        <td>".$i."</td>
        <td>".$nama_dok."</td>
        <td>".$jam_kerja."</td>
        <td>".$nama_spes."</td>
        <td><img class='img-responsive' src='foto/".$foto."' alt='' data-at2x='foto/".$foto. "' style='border-radius: 3px;' align='center' width='50' height='50'>
		<a href='foto/".$foto."' alt='' data-at2x='foto/".$foto. "' rel='prettyPhoto[gallery]'>
								<i class='fa fa-search-plus'></i>
		</td>
      </tr>
		</tbody>
	 "
	 ;
	$i++;
    
    }
   }
  }  
?>  
 </table>
 
	      
<?php 
  //pilih data dari tabel dokter
   $sql = "SELECT * FROM dokter WHERE id_spes LIKE '%$search%'";
//ambil query tampilkan
$hitung=mysql_query($sql);
//tampilkan data dalam bentuk array di tabel
$jumlah=mysql_num_rows($hitung);
?>
              <tr>
                <td colspan="4"><div align="center"><strong>Jumlah Dokter Adalah</strong> </div></td>
                <td colspan="2" align="center"><div align="center"><b><?php echo $jumlah; ?> orang</b></div></td>
              </tr>
</form>

										
										
										
									</div>
															</div>
						</div>
						<div class="panel-footer shares">

						</div>
					</div>
				</div> <!-- Col sm 8 -->


				<div class="col-sm-4">
<?php include "sub/sidebardirektur.php" ?>

</div>
</div>
</div>
</div>
</section>					

