<?php 

include "module/koneksi.php";
 
//ambil parameter
$id_prov = $_POST['id_prov'];
 
if($id_prov == ''){
     exit;
}else{
     $query = "SELECT id_kab, nama_kab FROM tbl_master_kab WHERE id_prov = '$id_prov' ORDER BY nama_kab";
    $result = mysql_query($query);
		while ($data = mysql_fetch_array($result)){
          echo '<option value="'.$data["id_kab"].'">'.$data["nama_kab"].'</option>';
     }
     exit;    
}
?>