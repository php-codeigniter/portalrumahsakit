-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2017 at 07:27 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portalrs`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
`id` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `judul` text NOT NULL,
  `isi_berita` text NOT NULL,
  `tanggal` date NOT NULL,
  `foto` varchar(125) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `kategori`, `judul`, `isi_berita`, `tanggal`, `foto`) VALUES
(1, '', '', '', '2017-06-04', 'hack.jpg'),
(2, '2', 'sfs', 'dfd', '2017-06-02', 'hack.jpg'),
(3, '2', 'Merupakan Anak Kandung dari Hacker Cantik', 'SaLam IT para Punggawa MAYA, KaLi ini ane bakaL mencoba mengajak agan2\r\ntuk sedikit MeLenturkan Jemari Pengetahuan Underground  Agan2 Seputar Cara Penggunaan\r\nCain & AbLeâ€¦..\r\nAne Pernah GoogLing, nyari tau tentang asaL muasaL Software Super Canggih ini,\r\ndan hasiLnya Cain AbLe Merupakan Anak Kandung dari Hacker Cantik  yang memimpin\r\n2200 Hacker Wanita Di Chinaâ€¦!!! WoWâ€¦\r\nSebut Saja â€œXIAO TIANâ€\r\nSoâ€¦ Langsung aja niiii Penampakannyaâ€¦â€¦\r\n', '2017-06-02', 'dd.jpg'),
(4, '', '3.	Untuk melakukan aksi sniffing, klik tab Sniffer', 'Hacking via LAN (snifing). Teknik nya disebut Man In The Middle attack (Apa itu?). Sniffing adalah sebuah aksi penyadapan terhadap setiap paket request dan reply di jaringan LAN. Melihat cara yang digunakan, sniffing dibagi kedalan dua kategori; passive sniffing yaitu melakukan penyadapan tanpa merubah data atau packet apapun dari jaringan sedangkan active sniffing merubah packet di jaringan atau mengirimkan packet dengan alamat MAC yang berubah-ubah secara acak dalam jumlah yang sangat banyak.\r\nActive sniffing biasanya menggunakan tool tambahan (yang biasa digunakan yaitu Etherflood), tapi kali ini kita hanya akan membahas bagaimana cara menggunakan passive sniffing dan tool yang kita gunakan adalah Cain & Abel.\r\nApa saja yang kita butuhkan?\r\n1. Software Cain & Abel, dapat di download di sini.\r\n2. Cari warnet yang rame\r\n3. Snack atau makanan ringan segukupnya Minuman.\r\n4. Apa aja yang dirasa perlu dechâ€¦\r\nTrusâ€¦.!!!! Apa saja langkah-langkah yang akan kita lakukan?\r\nLangkah-langkah yang harus dilakukan:\r\n1.	Install program Cain&Abel\r\n2.	Jalankan Cain\r\n3.	Untuk melakukan aksi sniffing, klik tab Sniffer\r\n', '2017-06-02', 'hack.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE IF NOT EXISTS `dokter` (
`id` int(11) NOT NULL,
  `nama_dok` varchar(100) NOT NULL,
  `jam_kerja` varchar(120) NOT NULL,
  `id_spes` int(11) NOT NULL,
  `foto` varchar(220) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id`, `nama_dok`, `jam_kerja`, `id_spes`, `foto`) VALUES
(8, 'vsdfsd', ' dsfs', 3, 'a.jpg'),
(9, 'asads', 'PKL: 09:00 s/d 12:00 WIB', 2, 'hack.jpg'),
(10, 'saktiawan', 'Pkl 08:00 s/d 09:00', 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
`id` int(11) NOT NULL,
  `user` varchar(120) NOT NULL,
  `pass` varchar(120) NOT NULL,
  `type` varchar(120) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `user`, `pass`, `type`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE IF NOT EXISTS `tbl_kategori` (
`id` int(11) NOT NULL,
  `nama_kat` varchar(50) NOT NULL,
  `ket_kat` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`id`, `nama_kat`, `ket_kat`) VALUES
(1, 'Remunerasi', ''),
(2, 'Kegiatan', ''),
(3, 'Pelayanan', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_profile`
--

CREATE TABLE IF NOT EXISTS `tbl_profile` (
`id` int(11) NOT NULL,
  `judul` text NOT NULL,
  `isi_profile` text NOT NULL,
  `kategori` int(11) NOT NULL,
  `foto` varchar(123) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_profile`
--

INSERT INTO `tbl_profile` (`id`, `judul`, `isi_profile`, `kategori`, `foto`) VALUES
(1, 'selamat malam selamat berjumpe', ' Mengikuti Diklat Prajabatan Gol. II Angkatan  VIII pada tanggal 18 Agustus 2015 sampai selesai  di  Hotel Kamanre Kota Palopo\r\nDemikian surat  tugas ini dibuat untuk dipergunakan sebagaimana mestinya.\r\n', 2, 'a.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_spesialis`
--

CREATE TABLE IF NOT EXISTS `tbl_spesialis` (
`id_spes` int(11) NOT NULL,
  `nama_spes` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_spesialis`
--

INSERT INTO `tbl_spesialis` (`id_spes`, `nama_spes`) VALUES
(1, 'Dokter Spesialis Bedah'),
(2, 'Dokter Spesialis Syaraf'),
(3, 'Dokter Spesialis Orthopedi'),
(4, 'Dokter Spesialis Mata');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_profile`
--
ALTER TABLE `tbl_profile`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_spesialis`
--
ALTER TABLE `tbl_spesialis`
 ADD PRIMARY KEY (`id_spes`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_profile`
--
ALTER TABLE `tbl_profile`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_spesialis`
--
ALTER TABLE `tbl_spesialis`
MODIFY `id_spes` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
