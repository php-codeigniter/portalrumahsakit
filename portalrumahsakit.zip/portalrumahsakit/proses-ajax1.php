<?php
include 'module/koneksi.php';
$id = $_GET['id'];
$query = "SELECT * FROM gaji where id = '$id'";
$mahasiswa = mysql_fetch_array($query);
$data = array(
            'nama'     =>  $mahasiswa['nama'],
            'jumlah_jam'    =>  $mahasiswa['jumlah_jam'],
            'status'    =>  $mahasiswa['status'],);
 echo json_encode($data);
?>