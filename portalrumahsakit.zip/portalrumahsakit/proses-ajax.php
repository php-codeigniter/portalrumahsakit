<?php
include 'module/koneksi.php';
$kode = $_GET['kode'];
$query = mysql_query("select * from tbl_data where kode='$kode'");
$mahasiswa = mysql_fetch_array($query);
$data = array(
            'nama'     =>  $mahasiswa['nama'],
 echo json_encode($data);
?>