 <?php
include "module/koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>portal desa</title>

    <!-- Bootstrap core CSS -->
    <link href="css/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/css/small-business.css" rel="stylesheet">


  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
	
	
	
      <div class="container">
        <a class="navbar-brand" href="#">Start Bootstrap</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                          <a class="nav-link" href="home.php?menu=home" title="BERANDA"><i class="fa fa-fw fa-home"></i>BERANDA
                <span class="sr-only">(current)</span>
              </a>
                     </li>
            




			              <li class="dropdown">
        <a class="nav-link" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-list-alt"></i> BERITA </a>
              <ul class="dropdown-menu">
             <li><?php
					$a="select*from tbl_kategori";
					$b=mysql_query($a);
					while($c=mysql_fetch_array($b))
					{
					?>
					   <li><a href="home.php?menu=beritacari&act=0&kategori=<?php echo $c['id'];?>"> <span class="glyphicon glyphicon-eye-open"></span> <?php echo $c['nama_kat'];?></a></li>
					<?php } ?> </a></li>
        </ul>
    
            </li>


			
			
			
			              <li class="dropdown">
        <a class="nav-link" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-list-alt"></i> RAJAL RANAP </a>
              <ul class="dropdown-menu">
 <li> <?php
					$a="select*from tbl_katpel";
					$b=mysql_query($a);
					while($c=mysql_fetch_array($b))
					{
					?>
					   <li><a href="home.php?menu=pelayanan&act=0&kategori=<?php echo $c['id'];?>"><i class="fa fa-info-circle"></i> <?php echo $c['nama_pel'];?></a></li>
					<?php } ?> </a></li>
        </ul>
    
            </li>


			
			
			
			
			
			
                 <li class="dropdown">
        <a class="nav-link" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-list-alt"></i> TENTANG KAMI </a>
              <ul class="dropdown-menu">
           				   <li><a href="home.php?menu=profile"> PROFILE </a></li>
					   <li><a href="home.php?menu=visi"> VISI MISI </a></li>
					   <li><a href="home.php?menu=sejarah"> SEJARAH </a></li>
					   <li><a href="home.php?menu=struktural"> STRUKTURAL </a></li>
        </ul>
    
            </li>
			
			

  
			
          <li class="nav-item">
              <a class="nav-link" href="home.php?menu=statistik" title="STATISTIK">GALERY</a>
            </li>
  
  
  
          <li class="nav-item">
              <a class="nav-link" href="home.php?menu=galeri" title="GALERY FOTO">GALERY</a>
            </li>
  
  
          <li class="nav-item">
              <a class="nav-link" href="home.php?menu=dokter" title="DOKTER">DOKTER</a>
            </li>

  
          <li class="nav-item">
              <a class="nav-link" href="home.php?menu=lokasi" title="LOKASI">LOKASI</a>
            </li>

			  <li class="nav-item">
              <a class="nav-link" href="home.php?menu=download" title="DOWNLOAD">DOWNLOAD</a>
            </li>






                    </ul>
        </div>
      </div>
    </nav>

	 <?php include "menu.php";?>
	
	<!-- Portfolio End -->
	 
 <?php
	include ("sub/footer.php");
?> 

</body>
</html>