<?php 

include "module/koneksi.php";
 
//ambil parameter
$id_kab = $_POST['id_kab'];
 
if($id_kab == ''){
     exit;
}else{
     $query = "SELECT id_kec, nama_kec FROM tbl_master_kec WHERE id_kab = '$id_kab' ORDER BY nama_kec";
    $result = mysql_query($query);
		while ($data = mysql_fetch_array($result)){
          echo '<option value="'.$data["id_kec"].'">'.$data["nama_kec"].'</option>';
     }
     exit;    
}
?>