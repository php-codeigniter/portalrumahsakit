<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Selamat Datang Admin </title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  
   <!-- DataTables CSS -->
    <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
    <!-- DataTables Responsive CSS -->
    <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
	<!--- CSS Select-->
	<link href="jquery/select/select2.min.css" rel="stylesheet">
	<!-- JS Select
    
-->
  <script>
  $( function() {
    $( "#tgl_bayar" ).datepicker({dateFormat: 'yy-mm-dd', changeMonth : true, changeYear : true});
    $( "#datepicker1" ).datepicker({dateFormat: 'yy-mm-dd', changeMonth : true, changeYear : true});
    $( "#datepicker2" ).datepicker({dateFormat: 'yy-mm-dd', changeMonth : true, changeYear : true});
  } );
  </script>
  <script>

function formatCurrency(num) {
num = num.toString().replace(/\$|\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+'.'+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + 'Rp. ' + num + ',' + cents);
}
</script>


<script type="text/javascript" src="jquery-1.7.2.min.js"></script>
 
<!-- Script Ajax untuk Mengontrol Dropdown List Bertingkat -->
<script type="text/javascript">
$(function() {
     $("#id_prov").change(function(){
          $("img#imgLoad").show(1000);
          var id_prov = $(this).val();
 
          $.ajax({
             type: "POST",
             dataType: "html",
             url: "get-kabupaten.php",
             data: "id_prov="+id_prov,
             success: function(msg){
                 if(msg == ''){
                         $("select#id_kab").html('<option value="">--Pilih Provinsi--</option>');
                         $("select#id_kec").html('<option value="">--Pilih Kota--</option>');
                 }else{
                           $("select#id_kab").html(msg);                                                       
                 }
                 $("img#imgLoad").hide(1000);
 
                 getAjaxAlamat();                                                        
             }
          });                    
     });
 
     $("#id_kab").change(getAjaxAlamat);
     function getAjaxAlamat(){
          $("img#imgLoadMerk").show(1000);
          var id_kab = $("#id_kab").val();
 
          $.ajax({
             type: "POST",
             dataType: "html",
             url: "get-kecamatan.php",
             data: "id_kab="+id_kab,
             success: function(msg){
                 if(msg == ''){
                         $("select#id_kec").html('<option value="">--Pilih Kota--</option>');                                                                                  
                 }else{
                           $("select#id_kec").html(msg);                              
                 }
                 $("img#imgLoadMerk").hide();                                                        
             }
          });
     }    
});
</script>


    <style type="text/css">
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .brand { font-family: georgia, serif; }
        .brand .first {
            color: #ccc;
            font-style: italic;
        }
        .brand .second {
            color: #fff;
            font-weight: bold;
        }
		@media.print {
		input.noPrint { display: none; }
		}
		


    </style>

</head>
 

    
    
	
    